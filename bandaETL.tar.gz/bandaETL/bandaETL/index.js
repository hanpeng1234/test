var AWS = require('aws-sdk');
var lambda = new AWS.Lambda();
var pg=require("pg");
var obj={
  "dbtype":"banda", 
  "user":"postgres",
  "database":"banda",
  "password":"vHeqPwro2HriV7CrM8Wh",
  "port":3433,
  "host":'pgm-d9jkp19xeyji7eatjo.pgsql.ap-southeast-5.rds.aliyuncs.com',
  "sql1":"SELECT   *   FROM pg_logical_slot_peek_changes('banda_stream_slot', null,null,'include-timestamp','1') limit 700",
  "sql2":"SELECT lsn, xid FROM pg_logical_slot_get_changes('banda_stream_slot','$last_lsn$',NULL) LIMIT 1",
  "sql3":"SELECT lsn, xid FROM pg_logical_slot_get_changes('banda_stream_slot',NULL,NULL)"
}
exports.handler = function(event, context) {
    var params = {
        FunctionName: 'cloud9-callFunction2-callFunction2-SIJBC1KUJ70L',
        InvocationType: 'RequestResponse',
        LogType: 'Tail',
        Payload:JSON.stringify(obj)
     };
     lambda.invoke(params, function(err, data) {
        if (err) {
             context.fail(err);
        } else {
            context.succeed('Lambda_TEST said '+ data.Payload);
        }
     })
};
