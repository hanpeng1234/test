var offset_GMT = new Date().getTimezoneOffset(); // 本地时间和格林威治的时间差，单位为分钟
var nowDate = new Date().getTime(); // 本地时间距 1970 年 1 月 1 日午夜（GMT 时间）之间的毫秒数
var d = new Date(nowDate + offset_GMT * 60 * 1000 + 8 * 60 * 60 * 1000);
var datestring = d.getFullYear()+ "-" + (d.getMonth()+1) + "-" + d.getDate()   + " " +
d.getHours()+ ":" + d.getMinutes()+ ":"+d.getSeconds()+"."+d.getMilliseconds();
console.log(datestring);
function a(){
    var offset_GMT = new Date().getTimezoneOffset(); // 本地时间和格林威治的时间差，单位为分钟
    var nowDate = new Date().getTime(); // 本地时间距 1970 年 1 月 1 日午夜（GMT 时间）之间的毫秒数
    var d = new Date(nowDate + offset_GMT * 60 * 1000 + 8 * 60 * 60 * 1000);
    var datestring = d.getFullYear()+ "-" + (d.getMonth()+1) + "-" + d.getDate()   + " " +
    d.getHours()+ ":" + d.getMinutes()+ ":"+d.getSeconds()+"."+d.getMilliseconds();
    return  datestring
}

// var str="timestamp with time zone"
// var bool=str.match("timestamp1");
// console.log(bool)
// var a=[2,2,44];
// var b=[];
// a=a.concat(b);
// console.log(a)
// try{
//     console.log(a);
// }catch(e){
//     console.log("error")
// }
// var a={"a":"b","a1":"b1"}
// var b ="qwwe";
//  try {
//     if (typeof JSON.parse(b) == "object") {
//          console.log(b)
//     }
// } catch(e) {
//     console.log(e)
// }
// // console.log(typeof(b))
// var a= {"id":"4861","sender":"ZENZIVA","send_trigger":"REGISTER","sendto":"081283919947","code":"647732","content":"Kode verifikasi anda untuk login ke Rupiah Plus adalah 647732","status":"SUCCESS1","create_time":1494082012570,"update_time":1494082012889,"send_id":null,"kind":"update","tableNm":"t_sms","schema":"public","etlDate":"2019-12-2 14:30:43.840","response":"<?xml version=\"1.0\" encoding=\"UTF-8\"?><response>  <message>    <messageId>MDM-3k1v96ldtpy7</messageId>    <to>6281283919947</to>    <status>0</status>    <text>Success</text>		<balance>6082</balance>  </message></response>"}
// // a["response"]=escape(a.response);
// // console.log(a);
// a=JSON.stringify(a);
// // console.log(a);
// var b=JSON.parse(a);

function getLocalDate(){
    var offset_GMT = new Date().getTimezoneOffset(); // 本地时间和格林威治的时间差，单位为分钟
    var nowDate = new Date("2019-12-01 02:59:50.017399+00").getTime(); // 本地时间距 1970 年 1 月 1 日午夜（GMT 时间）之间的毫秒数
    var d = new Date(nowDate + offset_GMT * 60 * 1000 + 8 * 60 * 60 * 1000);
    return  d.getFullYear()+ "-" + (d.getMonth()+1) + "-" + (d.getDate()<10?"0"+d.getDate():d.getDate())   + " " +
    d.getHours()+ ":" + d.getMinutes()+ ":"+d.getSeconds()+"."+d.getMilliseconds();
}
console.log(getLocalDate())


var json="{"+'\"'+"kind"+'\"'+":"+'\"'+1111+'\"'+","+'\"'+"etlDate"+'\"'+":"+'\"'+"w2222"+'\"'+","+'\"'+"etlIndex"+'\"'+":"+11+",";
console.log(json)