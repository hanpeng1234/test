console.log('Loading function');
var pg=require("pg");
var wal2json=require("./wal2Json");
var eg=require("./eg");
var firehose=require("./send2Firehose");
exports.handler = async function(event, context) {
    try {
          for(var i=0;i<30;i++){
            var sql1="SELECT   *   FROM pg_logical_slot_peek_changes('banda_stream_slot', null,null,'include-timestamp','1') limit 1000"
            var data = await query(sql1)
            var limitdata=data["rows"]
            if(limitdata.length>0){
              var last_lsn=limitdata[limitdata.length-1].lsn;
              var sql2="SELECT lsn, xid FROM pg_logical_slot_get_changes('banda_stream_slot','"+ last_lsn+"',NULL) LIMIT 1"
              await query(sql2);
              var returnMap = wal2json.wal2json(limitdata);
              if(returnMap){
              await  firehose.send2filehose(returnMap);
              }
            }else{
              break;
            }
          }
    } catch (err) {
      console.error('error', err);
    }
    return ;
};
const pool = new pg.Pool({  
     user:"postgres", //
    // database:"postgres",
    database:"banda",//proc
    // database:"lovina",
    password:"vHeqPwro2HriV7CrM8Wh", //proc
    // password:"dv0Kf587VNjEtAGta8iK",YINSHANBanda321!
    // password:"Urmv]A7keYqw~#?9]8k%",
    port:3433,//proc
    host: 'pgm-d9jkp19xeyji7eatjo.pgsql.ap-southeast-5.rds.aliyuncs.com',//proc
    // host: 'rm-d9jx79xi30ujo27hpoo.pgsql.ap-southeast-5.rds.aliyuncs.com',
    // host: 'lovina-test.ct3lmpqmpvcq.ap-southeast-1.rds.amazonaws.com',
    // 扩展属性
    max:20, // 连接池最大连接数
    idleTimeoutMillis:3000, // 连接最大空闲时间 3s
    });

async function query (q) {
      // console.log(q)
      const client = await pool.connect();
      let res;
      try {
        await client.query('BEGIN')
        try {
          res = await client.query(q)
          await client.query('COMMIT')
        } catch (err) {
          await client.query('ROLLBACK')
          throw err
        }
      } finally {
        client.release()
      }
    return res
}    
// function connectPgWithPool() {
    // 查询
  //   await pool.connect(function(err, client, done) {  
  //     if(err) {
  //       return console.error('数据库连接出错', err);
  //     }
  //     // 简单输出个 Hello World   //t_task_slot
  //     //
  //   await  client.query("SELECT    lsn, xid   FROM pg_logical_slot_peek_changes('banda_stream_slot', null,null,'include-timestamp','1')",[], function(err, result) {
  //       if(err) {
  //         done();
  //         return console.error('查询出错', err);
  //       }
  //       var alldata=result.rows;
  //       var index=Math.ceil(alldata.length/1000)
  //         for(var i=0;i<index;i++){
  //           await client.query("SELECT   *   FROM pg_logical_slot_peek_changes('banda_stream_slot', null,null,'include-timestamp','1') limit 1000",[], function(err, result) {
  //             if(err) {
  //               done();
  //               return console.error('查询出错', err);
  //             }
  //             var data=result.rows;
  //             if(data.length>0){
  //               console.log(alldata.length)
  //               console.log(1000*(i+1))
  //               var last_lsn=1000*(i+1)>alldata.length?alldata[alldata.length-1].lsn:alldata[1000*(i+1)].lsn;
  //               var sql="SELECT lsn, xid FROM pg_logical_slot_get_changes('banda_stream_slot','"+ last_lsn+"',NULL) LIMIT 1"
  //               await client.query(sql,[], function(err, result) {
  //                   if(err) {
  //                     return console.error('查询出错', err);
  //                   }
  //               });
  //               var returnMap = wal2json.wal2json(data);
  //               if(returnMap){
  //                 firehose.send2filehose(returnMap);
  //               }
  //             }else{
  //               done();
  //             }
  //         })
  //         }
  //     })
  // });
// } 




