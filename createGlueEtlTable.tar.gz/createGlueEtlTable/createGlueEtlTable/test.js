const AWS = require('aws-sdk');
const cloudwatchlog= new AWS.CloudWatchLogs({"accessKeyId ":"AKIA4OO3YD6F6H3BAHEZ","secretAccessKey":"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","region":"ap-southeast-1"});
var params = {
  logGroupName: '111111', /* required */
  kmsKeyId: 'arn:aws:logs:ap-southeast-1:855696220043:log-group:/aws/kinesisfirehose/banda_t_loan_app:*',
  tags: {
    '<TagKey>': 'STRING_VALUE',
    /* '<TagKey>': ... */
  }
};
cloudwatchlog.createLogGroup(params, function(err, data) {
  if (err) console.log(err, err.stack); // an error occurred
  else     console.log(data);           // successful response
});