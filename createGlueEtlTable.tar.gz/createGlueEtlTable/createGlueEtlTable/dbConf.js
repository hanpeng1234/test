var dbConf={
    "banda":{"dbtype":"banda", 
           "dbdemo":"banda_etl_table_demo",
           "user":"postgres",
           "database":"banda",
           "password":"vHeqPwro2HriV7CrM8Wh",
           "port":3433,
           "host":"pgm-d9jkp19xeyji7eatjo.pgsql.ap-southeast-5.rds.aliyuncs.com"},
    // "lovina":{
    //       "dbtype":"lovina", 
    //       "dbdemo":"lovina_etl_table_demo",
    //       "user":"postgres",
    //       "database":"lovina",
    //       "password":"UFXXExqnXJix9b2eM9Ge",
    //       "port":3433,
    //       "host":"lovina-prod.ct3lmpqmpvcq.ap-southeast-1.rds.amazonaws.com"
    // },
     "lovina":{
          "dbtype":"lovina", 
          "user":"master",
          "dbdemo":"lovina_etl_table_demo",
          "database":"lovina",
          "password":"Urmv]A7keYqw~#?9]8k%",
          "port":5432,
          "host":'lovina-test.ct3lmpqmpvcq.ap-southeast-1.rds.amazonaws.com',
     },
    "coupon":{
           "dbtype":"coupon", 
           "dbdemo":"coupon_etl_table_demo",
           "user":"elt_sync",
           "database":"coupon",
           "password":"VW7buZwvYWhVMusrkZN1",
           "port":5432,
           "host":"lovina-prod.ct3lmpqmpvcq.ap-southeast-1.rds.amazonaws.com"
    },
    "notification":{
           "dbtype":"notification", 
           "dbdemo":"notification_etl_table_demo",
           "user":"etl_sync",
           "database":"notification",
           "password":"3CN04h092qfU2FfUKzft",
           "port":5432,
           "host":"adapundi-services-cluster.cluster-ct3lmpqmpvcq.ap-southeast-1.rds.amazonaws.com"
    },
    "arkham":{
           "dbtype":"arkham", 
           "dbdemo":"arkham_etl_table_demo",
           "user":"master",
           "database":"arkham",
           "password":"f5LCyt8EbBQdetC5UHvt",
           "port":5432,
           "host":"credinex-prod-instance-1.ct3lmpqmpvcq.ap-southeast-1.rds.amazonaws.com"
    },
    "protoss":{
           "dbtype":"protoss", 
           "dbdemo":"protoss_etl_table_demo",
           "user":"master",
           "database":"protoss",
           "password":"f5LCyt8EbBQdetC5UHvt",
           "port":5432,
           "host":"credinex-prod-instance-1.ct3lmpqmpvcq.ap-southeast-1.rds.amazonaws.com"
    },
    "credinex_account":{
           "dbtype":"credinex_account", 
           "dbdemo":"credinex_account_etl_table_demo",
           "user":"master",
           "database":"account",
           "password":"f5LCyt8EbBQdetC5UHvt",
           "port":5432,
           "host":"credinex-prod-instance-1.ct3lmpqmpvcq.ap-southeast-1.rds.amazonaws.com"
    },
    "credinex_repeater":{
           "dbtype":"credinex_repeater", 
           "dbdemo":"credinex_repeater_etl_table_demo",
           "user":"master",
           "database":"repeater",
           "password":"f5LCyt8EbBQdetC5UHvt",
           "port":5432,
           "host":"credinex-prod-instance-1.ct3lmpqmpvcq.ap-southeast-1.rds.amazonaws.com"
    },
    "credinex_hive":{
           "dbtype":"credinex_hive", 
           "dbdemo":"credinex_hive_etl_table_demo",
           "user":"master",
           "database":"hive",
           "password":"f5LCyt8EbBQdetC5UHvt",
           "port":5432,
           "host":"credinex-prod-instance-1.ct3lmpqmpvcq.ap-southeast-1.rds.amazonaws.com"
    },
    "telemarket":{
           "dbtype":"telemarket", 
           "dbdemo":"telemarket_etl_table_demo",
           "user":"telemarket",
           "database":"telemarket",
           "password":"BCAocjmQ6AMkZGn512As",
           "port":5432,
           "host":"adapundi-services-cluster.cluster-ct3lmpqmpvcq.ap-southeast-1.rds.amazonaws.com"
    }
}
var sql=" SELECT a.attnum, a.attname AS field, t.typname AS type, a.attlen AS length, a.atttypmod AS lengthvar, a.attnotnull AS notnull, b.description AS comment FROM pg_class c, pg_attribute a LEFT OUTER JOIN pg_description b ON a.attrelid=b.objoid AND a.attnum = b.objsubid, pg_type t WHERE c.relname ='#tableNm#' and a.attnum > 0 and a.attrelid = c.oid and a.atttypid = t.oid ORDER BY a.attnum"
var columeKey={
    "int8":"bigint", 
    "varchar":"string",
    "int4":"int",
    "timestamptz":"timestamp",
    "bool":"string",
    "boolean":"string",
    "text":"string",
    "json":"string",
    "decimal":"decimal(28,8)",
    "numeric":"decimal(28,8)",
    "float4":"float",
    "float8":"float",
    "uuid":"string"
}
var glueTable_demo={
    "DatabaseName":"STRING_VALUE",
    "TableInput":{
        "Name":"STRING_VALUE",
        "Description":"",
        "LastAccessTime":"Wed Dec 31 1969 16:00:00 GMT-0800 (PST)",
        "LastAnalyzedTime":"Wed Dec 31 1969 16:00:00 GMT-0800 (PST)",
        "Parameters":{
            "CrawlerSchemaDeserializerVersion":"1.0",
            "compressionType":"none",
            "CrawlerSchemaSerializerVersion":"1.0",
            "classification":"orc",
            "typeOfData":"file"
        },
        "PartitionKeys":[
            {
                "Type":"string",
                "Name":"year"
            },
            {
                "Type":"string",
                "Name":"month"
            },
            {
                "Type":"string",
                "Name":"day"
            }
        ],
        "Retention":0,
        "StorageDescriptor":{
            "BucketColumns":[

            ],
            "Columns":[
                {
                    "Type":"string",
                    "Name":"kind"
                },
                {
                    "Type":"string",
                    "Name":"etldate"
                },
                {
                    "Type":"int",
                    "Name":"etlindex"
                }
            ],
            "Compressed":false,
            "InputFormat":"org.apache.hadoop.hive.ql.io.orc.OrcInputFormat",
            "Location":"",
            "NumberOfBuckets":0,
            "OutputFormat":"org.apache.hadoop.hive.ql.io.orc.OrcOutputFormat",
            "Parameters":{
                "CrawlerSchemaDeserializerVersion":"1.0",
                "compressionType":"none",
                "CrawlerSchemaSerializerVersion":"1.0",
                "classification":"orc",
                "typeOfData":"file"
            },
            "SerdeInfo":{
                "Parameters":{

                },
                "SerializationLibrary":"org.apache.hadoop.hive.ql.io.orc.OrcSerde"
            },
            "SortColumns":[

            ],
            "StoredAsSubDirectories":false
        },
        "TableType":"EXTERNAL_TABLE"
    }
}
var firehose_demo= {
  DeliveryStreamName: 'STRING_VALUE',
  DeliveryStreamType: "DirectPut",
  ExtendedS3DestinationConfiguration: {
    BucketARN: 'arn:aws:s3:::rupiahplus-data-warehouse',
    RoleARN: 'arn:aws:iam::855696220043:role/firehose_delivery_role',
    BufferingHints: {
      IntervalInSeconds: '900',
      SizeInMBs: '128'
    },
    CloudWatchLoggingOptions: {
      Enabled: true,
      LogGroupName: "/aws/kinesisfirehose/banda_t_admin",
      LogStreamName:"S3Delivery"
    },
    CompressionFormat: "UNCOMPRESSED",
    DataFormatConversionConfiguration: {
      Enabled: true,
      InputFormatConfiguration: {
        Deserializer: {
          OpenXJsonSerDe: {}
        }
      },
      OutputFormatConfiguration: {
        Serializer: {
          OrcSerDe: {},
        }
      },
      SchemaConfiguration: {
        DatabaseName: 'banda_etl_table_demo',
        Region: 'ap-southeast-1',
        RoleARN: 'arn:aws:iam::855696220043:role/firehose_delivery_role',
        TableName: 'banda_t_admin_demo',
        VersionId: 'LATEST'
      }
    },
    EncryptionConfiguration: {
      NoEncryptionConfig: "NoEncryption"
    },
    ErrorOutputPrefix: 'stream/banda_etl/t_admin_failed/',
    Prefix:"stream/banda_etl/t_admin/year=!{timestamp:yyyy}/month=!{timestamp:MM}/day=!{timestamp:dd}/",
    ProcessingConfiguration: {
      Enabled: false,
      Processors: []
    },
    S3BackupMode:"Disabled"
  },
};
module.exports.dbConf = dbConf
module.exports.sql = sql
module.exports.columeKey = columeKey
module.exports.glueTable_demo = glueTable_demo
module.exports.firehose_demo = firehose_demo