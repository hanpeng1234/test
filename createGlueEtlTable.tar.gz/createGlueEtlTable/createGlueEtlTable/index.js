console.log('Loading function');
var pg=require("pg");
var dbconf=require("./dbConf");
const AWS = require('aws-sdk');
const glue =new AWS.Glue({"accessKeyId ":"AKIA4OO3YD6F6H3BAHEZ","secretAccessKey":"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","region":"ap-southeast-1"})
const firehoseclient =new AWS.Firehose({"accessKeyId ":"AKIA4OO3YD6F6H3BAHEZ","secretAccessKey":"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","region":"ap-southeast-1"})
const cloudwatchlog= new AWS.CloudWatchLogs({"accessKeyId ":"AKIA4OO3YD6F6H3BAHEZ","secretAccessKey":"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","region":"ap-southeast-1"});
var pool=null;
// ###########################需要配置的东西##############################
//！！！！！！！先在dbConf.js里添加数据库连接配置！！！！！！！！
const bdtype="banda"


const tablelist=[
          "t_trigger_group"
]
// #############################################################
const glueLocation="s3://rupiahplus-data-warehouse/stream/"+bdtype+"_etl_demo/";
const dblink=dbconf["dbConf"][bdtype]
exports.handler = async function(event, context) {
  var glueTable_demo=dbconf.glueTable_demo;
  var firehose_demo=dbconf.firehose_demo;
  const columeKey=dbconf.columeKey;
  //初始化数据库连接
  initPool(dblink["user"],dblink["database"],dblink["password"],dblink["port"],dblink["host"])
  try {
    for(var i=0;i<tablelist.length;i++){
        var sql=dbconf["sql"].replace("#tableNm#",tablelist[i]);
        var data =  await query(sql)
        var limitdata=data["rows"]
        var columlist=limitdata.map((value)=>{
          var colum={};
          colum["Type"]=columeKey[value["type"]]?columeKey[value["type"]]:value["type"]
          colum["Name"]=value["field"]
          return colum
        })
        //合并列
        var awsTableNm=dblink["dbtype"]+"_"+tablelist[i]+"_demo";
        //创建demo表
        await createGuleTable(glueTable_demo,dblink["dbdemo"],awsTableNm,columlist,tablelist[i])
        // // 生成firehose
        await createFirehose(firehose_demo,dblink["dbtype"],dblink["dbdemo"],awsTableNm,tablelist[i])
    }
  } catch (err) {
    console.error('error', err);
  }
};
//创建demo表
async function createGuleTable(glueTable,DatabaseName,awsTableNm,columlist,tableNm){
    var glueTable_demo=clone(glueTable)
    glueTable_demo["DatabaseName"]=DatabaseName;
    glueTable_demo["TableInput"]["Name"]=awsTableNm;
    glueTable_demo["TableInput"]["LastAccessTime"]=new Date();
    glueTable_demo["TableInput"]["LastAnalyzedTime"]=new Date();
    glueTable_demo["TableInput"]["StorageDescriptor"]["Columns"].push.apply(glueTable_demo["TableInput"]["StorageDescriptor"]["Columns"],columlist);
    glueTable_demo["TableInput"]["StorageDescriptor"]["Location"]=glueLocation+tableNm;
    //创建demo表
    await glue.createTable(glueTable_demo).promise();
}
//创建firehose
async function createFirehose(firehose,dbtype,dbdemo,awsTableNm,tableNm){
    var firehose_demo=clone(firehose)
    firehose_demo["DeliveryStreamName"]=dbtype+"_"+tableNm;
    var logName="/aws/kinesisfirehose/"+dbtype+"_"+tableNm;
    //创建日志组和日志流
    await createcLoudwatch(logName)
    firehose_demo["ExtendedS3DestinationConfiguration"]["CloudWatchLoggingOptions"]["LogGroupName"]=logName;
    firehose_demo["ExtendedS3DestinationConfiguration"]["DataFormatConversionConfiguration"]["SchemaConfiguration"]["DatabaseName"]=dbdemo;
    firehose_demo["ExtendedS3DestinationConfiguration"]["DataFormatConversionConfiguration"]["SchemaConfiguration"]["TableName"]=awsTableNm;
    firehose_demo["ExtendedS3DestinationConfiguration"]["ErrorOutputPrefix"]="stream/"+dbtype+"_etl_failed/"+tableNm+"_failed/";
    firehose_demo["ExtendedS3DestinationConfiguration"]["Prefix"]="stream/"+dbtype+"_etl/"+tableNm+"/year=!{timestamp:yyyy}/month=!{timestamp:MM}/day=!{timestamp:dd}/"
    await firehoseclient.createDeliveryStream(firehose_demo).promise();
}
//创建cloudwatchGroup
async function createcLoudwatch(logName){
    var arn="arn:aws:logs:ap-southeast-1:855696220043:log-group:";
    console.log(arn+logName+":*")
    var params = {
      logGroupName:logName
    };
    await cloudwatchlog.createLogGroup(params).promise();
    var params = {
      logGroupName: logName, 
      logStreamName: 'S3Delivery'
    };
    await cloudwatchlog.createLogStream(params).promise();
}
// //创建firehose
// async function updateFirehose(firehose_demo,dbtype,dbdemo,awsTableNm,tableNm){
//     firehose_demo["DeliveryStreamName"]=dbtype+"_"+tableNm;
//     firehose_demo["ExtendedS3DestinationConfiguration"]["CloudWatchLoggingOptions"]["LogGroupName"]="/aws/kinesisfirehose/"+tableNm;
//     firehose_demo["ExtendedS3DestinationConfiguration"]["DataFormatConversionConfiguration"]["SchemaConfiguration"]["DatabaseName"]=dbdemo;
//     firehose_demo["ExtendedS3DestinationConfiguration"]["DataFormatConversionConfiguration"]["SchemaConfiguration"]["TableName"]=awsTableNm;
//     firehose_demo["ExtendedS3DestinationConfiguration"]["ErrorOutputPrefix"]="stream/"+dbtype+"_etl/"+tableNm+"_failed/";
//     firehose_demo["ExtendedS3DestinationConfiguration"]["Prefix"]="stream/"+dbtype+"_etl/"+tableNm+"/year=!{timestamp:yyyy}/month=!{timestamp:MM}/day=!{timestamp:dd}/"
//     await firehose.createDeliveryStream(firehose_demo).promise();
// }
function initPool(user,database,password,port,host){
    pool = new pg.Pool({  
        user:user, //
        database:database,//proc
        password:password, //proc
        port:port,
        host: host,
        // 扩展属性
        max:20, // 连接池最大连接数
        idleTimeoutMillis:3000, // 连接最大空闲时间 3s
    });
}
function clone(a) {
   return JSON.parse(JSON.stringify(a));
}
async function query (q) {
      // console.log(q)
      const client = await pool.connect();
      let res;
      try {
        await client.query('BEGIN')
        try {
          res = await client.query(q)
          await client.query('COMMIT')
        } catch (err) {
          await client.query('ROLLBACK')
          throw err
        }
      } finally {
        client.release()
      }
    return res
}  




