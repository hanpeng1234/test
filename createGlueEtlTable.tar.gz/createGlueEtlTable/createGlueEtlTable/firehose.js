var params = {
  DeliveryStreamName: 'STRING_VALUE',
  DeliveryStreamType: "DirectPut",
  ExtendedS3DestinationConfiguration: {
    BucketARN: 'arn:aws:s3:::rupiahplus-data-warehouse',
    RoleARN: 'arn:aws:iam::855696220043:role/firehose_delivery_role',
    BufferingHints: {
      IntervalInSeconds: '128',
      SizeInMBs: '900'
    },
    CloudWatchLoggingOptions: {
      Enabled: true,
      LogGroupName: "/aws/kinesisfirehose/banda_t_admin",
      LogStreamName:"S3Delivery"
    },
    CompressionFormat: "UNCOMPRESSED",
    DataFormatConversionConfiguration: {
      Enabled: true,
      InputFormatConfiguration: {
        Deserializer: {
          OpenXJsonSerDe: {}
        }
      },
      OutputFormatConfiguration: {
        Serializer: {
          OrcSerDe: {},
        }
      },
      SchemaConfiguration: {
        DatabaseName: 'banda_etl_table_demo',
        Region: 'ap-southeast-1',
        RoleARN: 'arn:aws:iam::855696220043:role/firehose_delivery_role',
        TableName: 'banda_t_admin_demo',
        VersionId: 'LATEST'
      }
    },
    EncryptionConfiguration: {
      NoEncryptionConfig: "NoEncryption"
    },
    ErrorOutputPrefix: 'stream/banda_etl/t_admin_failed/',
    Prefix:"stream/banda_etl/t_admin/year=!{timestamp:yyyy}/month=!{timestamp:MM}/day=!{timestamp:dd}/",
    ProcessingConfiguration: {
      Enabled: false,
      Processors: []
    },
    S3BackupMode:"Disabled"
  },
  S3DestinationConfiguration: {
    BucketARN: 'arn:aws:s3:::rupiahplus-data-warehouse', 
    RoleARN: 'arn:aws:iam::855696220043:role/firehose_delivery_role', 
    BufferingHints: {
      IntervalInSeconds: '128',
      SizeInMBs: '900'
    },
    CloudWatchLoggingOptions: {
      Enabled: true || false,
      LogGroupName: '/aws/kinesisfirehose/banda_t_admin',
      LogStreamName: 'S3Delivery'
    },
    CompressionFormat: "UNCOMPRESSED",
    EncryptionConfiguration: {
      NoEncryptionConfig: "NoEncryption"
    },
    ErrorOutputPrefix: 'stream/banda_etl/t_admin_failed/',
    Prefix: 'stream/banda_etl/t_admin/year=!{timestamp:yyyy}/month=!{timestamp:MM}/day=!{timestamp:dd}/'
  }
};
