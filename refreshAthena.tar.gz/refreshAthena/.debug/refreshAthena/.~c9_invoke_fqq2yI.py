import boto3
# import configparser
import math
import time
s3client = boto3.client('s3')
s3 = boto3.resource('s3')
client = boto3.client('athena')
database = 'test_database'
import os
batch_num=os.environ['batch_num'] if hasattr(os.environ,"batch_num") and os.environ['batch_num'] else 5
def lambda_handler(event, context):
    sql_list=downloadsqlFile()
    # print(len(sql_list))
    curr_num=1
    i=0
    while i<math.ceil(len(sql_list)/batch_num):
    # for i in math.ceil(len(sql_list)/batch_num):
        # print(i*batch_num,(i+1)*batch_num-1 if (i+1)*batch_num-1<len(sql_list) else len(sql_list))
        sleep(sql_list[i*batch_num:(i+1)*batch_num-1 if (i+1)*batch_num-1<len(sql_list) else len(sql_list)])
        # print(sql_list[i*batch_num:(i+1)*batch_num-1 if (i+1)*batch_num-1<len(sql_list) else len(sql_list)])
        i=i+1
    # result_list=executeSqllist(sql_list,[])
    # quenedList=getsqlState(result_list)
    # print(quenedList)
    return ''
def sleep(a):
    print(a)
    time.sleep(100)
def tolist(i):
    strlist=i.split("=",1)
    return {strlist[0]:strlist[1]}

def downloadsqlFile():
    rescouceBucket = "rupiahplus-configs"
    rescouceKey = "etl/quicksite_sql/day/"
    bucket = s3.Bucket(rescouceBucket)
    sql_list = []
    for obj in bucket.objects.filter(Prefix=rescouceKey):
        filePath=obj.key
        body=obj.get()['Body'].read()
        if not str.endswith(filePath, "/"):
            sqllist=str.split(str(body, encoding = "utf-8"),"\r\n")
            sqllist.pop(0)
            a=list(map(tolist, sqllist))
            sql_list=sql_list+a;
    # print(sql_list)
    return sql_list
def run_query(query, database, s3_output):
    response = client.start_query_execution(
        QueryString=query,
        QueryExecutionContext={
            'Database': database
            },
        ResultConfiguration={
            'OutputLocation': s3_output,
            }
        )
    print('Execution ID: ' + response['QueryExecutionId'])
    return response["QueryExecutionId"]
# 处理sql语句
def executeSqllist(sql_list,list):
    sqlmap= sql_list[0]
    # for sqlmap in sql_list[0]:
    print(sqlmap)
    for table in sqlmap:
        sql=sqlmap[table]
        s3_ouput="s3://rupiahplus-data-warehouse/stream/athena_result/day"+table
        queryExecutionId=run_query(sqlmap[table], database, s3_ouput)
        list.append(queryExecutionId)
    return list
def getsqlState(ls):
    quenedList = [];
    print("59 line -------------------------", ls)
    for res in ls:
        QueryExecutionId = res
        response = client.get_query_execution(
            QueryExecutionId=QueryExecutionId
        )
        if response["QueryExecution"]["Status"]["State"] != "SUCCEEDED":
            quenedmap = {}
            quenedmap["QueryExecutionId"] = QueryExecutionId
            quenedmap["State"] = response["QueryExecution"]["Status"]["State"]
            #
            if response["QueryExecution"]["Status"] and "StateChangeReason" in response["QueryExecution"][
                "Status"].keys():
                quenedmap["Query"] = response["QueryExecution"]["Query"]
                quenedmap["Error"] = response["QueryExecution"]["Status"]["StateChangeReason"]
            quenedList.append(quenedmap)
    # time.sleep(300)
    return quenedList
# def filterList(list,i):
#     rtn_ls=[]
#     # 
#     return 