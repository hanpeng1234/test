import boto3
import configparser
s3client = boto3.client('s3')
s3 = boto3.resource('s3')
def lambda_handler(event, context):
    file_list=downloadsqlFile()
    getSqlList(file_list)
    return ''

def downloadsqlFile():
    rescouceBucket = "rupiahplus-configs"
    rescouceKey = "etl/quicksite_sql/day/"
    bucket = s3.Bucket(rescouceBucket)
    file_list=[]
    for obj in bucket.objects.filter(Prefix=rescouceKey):
        filePath=obj.key
        namelist = str.split(filePath, "/")
        if not str.endswith(filePath, "/"):
            filename = namelist[len(namelist) - 1];
            map={}
            map["name"] = filename
            map["key"]=filePath
            # 下载
            tempFilepath="/tmp/"+filename
            s3client.download_file(Filename=tempFilepath, Key=filePath,Bucket=rescouceBucket);
            file_list.append(tempFilepath)
    return file_list

# with open('conf.properties','r') as file:
#     for line in file.readlines():
#         print(line)
def getSqlList(file_list):
    list = []
    ticket_config = configparser.ConfigParser()
    for file in file_list:
        ticket_config.read(file)
        for r in ticket_config.options("sql"):
              list.append({r:ticket_config.get("sql", r)})
    print(list)