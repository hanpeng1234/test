const dateformat = require('dateformat');
var tableConfig=null;
function wal2json(data,tableConf){ 
   tableConfig=tableConf
   var returnMap={};
   data.forEach(function(map){
     returnMap=  truncate(map,returnMap);
   });
   return returnMap;
}
function truncate(map,returnMap){
    var jsondata=JSON.parse(map.data);
    var changeList= jsondata.change;
    var etldate_timestamp=jsondata.timestamp;
    var changeindex=changeList.length;
    var index=0;
    for(var j=0;j<changeList.length;j++){
        var change=changeList[j];
        var kind=change.kind;
        var tableNm=change.table;
        var schema=change.schema;
        if("public"==schema&&tableConfig[tableNm]) {
            var etldate= formatDate2(etldate_timestamp);
            var json="";
            if(kind!="delete"){
                json="{"+'\"'+"kind"+'\"'+":"+'\"'+kind+'\"'+","+'\"'+"etlDate"+'\"'+":"+'\"'+etldate+'\"'+","+'\"'+"etlIndex"+'\"'+":"+j+",";
                var columnvalues= change.columnvalues;
                var columnnames=change.columnnames;
                var columntypes=change.columntypes;
                for(var i=0;i<columnnames.length;i++){
                    var istimestamp= columntypes[i].match("timestamp")
                    if(istimestamp&&istimestamp["index"]>=0){
                       json+='\"'+columnnames[i]+'\"'+":"+(columnvalues[i]?JSON.stringify(new Date(columnvalues[i])):null)+",";
                    }else{
                    //   json+='\"'+columnnames[i]+'\"'+":"+(columnvalues[i]?JSON.stringify(columnvalues[i]):columnvalues[i]==""?null:JSON.stringify(columnvalues[i]))+",";
                       json+='\"'+columnnames[i]+'\"'+":"+(JSON.stringify(columnvalues[i]))+",";
                    }
                }
                json=json.substr(0,json.length-1)
                json+="}";
                if(!returnMap[tableNm]){
                   returnMap[tableNm]=[]; 
                }
                returnMap[tableNm].push(JSON.parse(json));
                index++;
            }else if(kind=="delete"){
                json="{"+'\"'+"kind"+'\"'+":"+'\"'+kind+'\"'+","+'\"'+"etlDate"+'\"'+":"+'\"'+etldate+'\"'+","+'\"'+"etlIndex"+'\"'+":"+j+",";
                var keynames= change.oldkeys.keynames;
                var keyvalues=change.oldkeys.keyvalues;
                var keytypes=change.oldkeys.keytypes;
                for(var i=0;i<keynames.length;i++){
                    var istimestamp= keytypes[i].match("timestamp")
                    if(istimestamp&&istimestamp["index"]>=0){
                        json+='\"'+keynames[i]+'\"'+":"+(keyvalues[i]?JSON.stringify(new Date(keyvalues[i])):null)+",";
                    }else{
                        json+='\"'+keynames[i]+'\"'+":"+(JSON.stringify(keyvalues[i]))+",";
                    //   json+='\"'+keynames[i]+'\"'+":"+(keyvalues[i]?JSON.stringify(keyvalues[i]):keyvalues[i]==""?null:JSON.stringify(keyvalues[i]))+",";
                    }
                    // json+='\"'+keynames[i]+'\"'+":"+(keyvalues[i]!=null?'\"'+keyvalues[i]+'\"':keyvalues[i])+",";
                }
                json=json.substr(0,json.length-1)
                json+="}"
                if(!returnMap[tableNm]){
                    returnMap[tableNm]=[]; 
                }
                returnMap[tableNm].push(JSON.parse(json));
                index++;
            }
        }else{
            changeindex--;
        } 
    }
    if(changeindex!=0&&changeindex!=index){
        console.log("Data_Difference-------------"+changeindex+"--------------------"+index);
        console.log(changeList);
    }
    return returnMap;
}
function getLocalDate(date){
    var offset_GMT = new Date().getTimezoneOffset(); // 本地时间和格林威治的时间差，单位为分钟
    var nowDate = new Date(date).getTime(); // 本地时间距 1970 年 1 月 1 日午夜（GMT 时间）之间的毫秒数
    var d = new Date(nowDate + offset_GMT * 60 * 1000 + 8 * 60 * 60 * 1000);
    return  d.getFullYear()+ "-" + (d.getMonth()+1) + "-" + (d.getDate()<10?"0"+d.getDate():d.getDate())   + " " +
    d.getHours()+ ":" + d.getMinutes()+ ":"+d.getSeconds()+"."+d.getMilliseconds();
}
function formatDate(date){
    var d = new Date(date);
    return  d.getFullYear()+ "-" + (d.getMonth()+1) + "-" + (d.getDate()<10?"0"+d.getDate():d.getDate())   + " " +
    d.getHours()+ ":" + d.getMinutes()+ ":"+d.getSeconds()+"."+d.getMilliseconds();
}
function formatDate2(date){
    var now = new Date(date);
    return dateformat(now, "yyyy-mm-dd HH:MM:ss.l");
}
function verifyJson(word){
    try {
        if (typeof JSON.parse(word) == "object") {
            return true
        }
    } catch(e) {
        return false;
    }
    return false;
}

module.exports = {
 wal2json
};