const AWS = require('aws-sdk');
const firehose = new AWS.Firehose({"accessKeyId ":"AKIA4OO3YD6F6H3BAHEZ","secretAccessKey":"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","region":"ap-southeast-1"});
var kinesis = new AWS.Kinesis();
// var tableMap = require('./tableConfig');
async  function send2filehose(returnMap,tableMap){
   if(returnMap){
        for(var key in returnMap) {
            var recordlist_all=[];
            recordlist_all= returnMap[key].map(value=>{
                return {Data:Buffer.from(JSON.stringify(value, null, 2))}
            })
            var recordlist=[];
            for(var a=0;a<recordlist_all.length;a++){
                if(a==0){
                    var list_child=[];
                    var recordlist=[];
                    list_child.push(recordlist_all[0])
                }else{
                    if(a%400==0){
                        list_child.push(recordlist_all[a])
                        recordlist.push(list_child);
                        list_child=[]
                    }else{
                        list_child.push(recordlist_all[a])
                    }
                }
                if(a==recordlist_all.length-1&&list_child.length>0){
                    recordlist.push(list_child);
                }
            }
            for(var i=0;i<recordlist.length;i++){
                var params = {
                    DeliveryStreamName: tableMap[key],
                    Records: recordlist[i]
                };
                await data2Firehose(params,tableMap[key])
                // await firehose.putRecordBatch(params).promise();
            }
        }
    }
}
async function data2Firehose(params){
  try {
        let data = await firehose.putRecordBatch(params).promise()
        var failecnt=data["FailedPutCount"]
            if(failecnt>0){
                params.Records=params.Records.slice(params.Records.length-failecnt,params.Records.length)
                await data2Firehose(params)
            }
    } catch(error){
               await data2Firehose(params);
               console.log("error: " + error.message);
    }
}
// async function data2Firehose(params){
//   try{
//         await firehose.putRecordBatch(params).promise().then((data)=>{
//             var failecnt=data["FailedPutCount"]
//             if(failecnt>0){
//                 params.Records=params.Records.slice(params.Records.length-failecnt,params.Records.length)
//                 data2Firehose(params)
//             }
//             }).catch((error) =>{
//               data2Firehose(params);
//               console.log("error: " + error.message);
//             });
//         }catch(e){
//             console.log("出错了！！！")
//             console.log(e)
//             console.log(e=="Records size exceeds 4 MB limit")
//         }
// }
module.exports = {
 send2filehose
};