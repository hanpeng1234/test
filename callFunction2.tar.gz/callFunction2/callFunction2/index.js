var tableNmConf=require("./tableConfig");
var wal2json=require("./wal2Json");
var firehose=require("./send2Firehose");
var pg=require("pg");
var pool=null;
var reg=/[\[][0-9]{18},/g
// sql1.replace("#$last_lsn$#","12345")
exports.handler = async function(event, context) {
    console.log("dbtype is ------------"+event["dbtype"])
    var tableConf=tableNmConf[event["dbtype"]]
    if(!tableConf){
      return
    }
    var dbtype=event["dbtype"]
    initPool(event["user"],event["database"],event["password"],event["port"],event["host"])
    for(var i=0;i<30;i++){
      var data = await query(event["sql1"])
      var limitdata=[]
      if(data&&data["rows"]){
        limitdata=data["rows"]
      }
      if(event["dbtype"]=='protoss'){
        var b=JSON.stringify(limitdata)
        b=b.replace(reg,function(item){return '[\\"'+item.substring(1,item.length-1)+'\\",'});
        limitdata= JSON.parse(b)
      }
      // if(event["dbtype"]=='banda'){
      //   console.log(limitdata)
      // }
      // dbtype=='coupon'
      if(limitdata.length>0||isLittleDatabase(dbtype)){
        var sql2=null;
        if(limitdata.length==0){
          //coupon库数据少,测试发现，没有操作也会造成wallog日志空间增加，所以跑一下pg_logical_slot_get_changes
          sql2=event["sql3"];
          await query(sql2);
          break;
        }else{
          var last_lsn=limitdata[limitdata.length-1].lsn;
          sql2=event["sql2"].replace("$last_lsn$",last_lsn);
          await query(sql2);
          var returnMap = wal2json.wal2json(limitdata,tableConf);
          if(returnMap&&dbtype!='banda_test'){
            await  firehose.send2filehose(returnMap,tableConf);
          }
        }
      }else{
        break;
      }
    }
    // } catch (err) {
    //   console.error('error', err);
    // }
    // return ;
};
function initPool(user,database,password,port,host){
    pool = new pg.Pool({  
        user:user, //
        database:database,//proc
        password:password, //proc
        port:port,
        host: host,
        // 扩展属性
        max:20, // 连接池最大连接数
        idleTimeoutMillis:3000, // 连接最大空闲时间 3s
    });
}
function isLittleDatabase(dbtype){
    var dblist={"coupon":true,
                "notification":true,
                "arkham":true,
                "protoss":true,
                "credinex_account":true,
                "credinex_repeater":true,
                "credinex_hive":true,
                "telemarket":true
    }
    if(dblist[dbtype]&&dblist[dbtype]==true){
       return true
    }
    return false
}

async function query (q) {
      let res;
      // console.log(q)
      try{
      const client = await pool.connect();
        try {
          await client.query('BEGIN')
          try {
            res = await client.query(q)
            await client.query('COMMIT')
          } catch (err) {
            await client.query('ROLLBACK')
            console.error("etl_error--------",err)
            console.error(res)
          }
        } catch (err1) {
            console.error("etl_begin_error--------",err1)
        } finally {
          client.release()
        }
      }catch(err2){
         console.error("connect_error--------",err2)
      }
     
      
    return res
}  