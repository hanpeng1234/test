import boto3
import time
import uuid
client = boto3.client('emr')
s3 = boto3.client('s3')
s3_resource = boto3.resource('s3')
qsclient = boto3.client('quicksight')
emrclient = boto3.client('emr')
def lambda_handler(event, context):
    print(boto3)
    return ''