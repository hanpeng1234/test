// const AWS = require('aws-sdk');
// const firehose = new AWS.Firehose({"accessKeyId ":"AKIA4OO3YD6F6H3BAHEZ","secretAccessKey":"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","region":"ap-southeast-1"});
// var kinesis = new AWS.Kinesis();
// var tableMap = require('./tableNm_conf');
// async  function send2filehose(channel,map,client_id,relItem){
//     // console.log("send2Firehose_id____",map['item'].id);
//     if(channel){
//         switch (channel){
//             case "10":
//                 var recordlist=[];
//                 recordlist.push({Data:Buffer.from(JSON.stringify(map, null, 2))});
//                 var params = {
//                     DeliveryStreamName: tableMap.map[channel].main,
//                     Records: recordlist
//                 };
//                 await firehose.putRecordBatch(params).promise();
//                 break;
//             case "20":
//                 if(map.friends_info&&map.friends_info.length>0){
//                   var friends_info = map.friends_info.map((value)=>{
//                       return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                   });
//                     var params = {
//                     DeliveryStreamName: tableMap.map[channel].friends_info,
//                     Records: friends_info
//                         };
//                     await firehose.putRecordBatch(params).promise();
//                 };
//                 if(map.education_info_college_info&&map.education_info_college_info.length>0){
//                   var education_info_college_info = map.education_info_college_info.map((value)=>{
//                       return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                   });
//                     var params = {
//                     DeliveryStreamName: tableMap.map[channel].education_info_college_info,
//                     Records: education_info_college_info
//                         };
//                     await firehose.putRecordBatch(params).promise();
//                 };
//                 if(map.education_info_highschool_info&&map.education_info_highschool_info.length>0){
//                   var education_info_highschool_info = map.education_info_highschool_info.map((value)=>{
//                       return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                   });
//                     var params = {
//                     DeliveryStreamName: tableMap.map[channel].education_info_highschool_info,
//                     Records: education_info_highschool_info
//                         };
//                     await firehose.putRecordBatch(params).promise();
//                 };
//                 if(map.messenger_info&&map.messenger_info.length>0){
//                   var messenger_info = map.messenger_info.map((value)=>{
//                       return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                   });
//                     var params = {
//                     DeliveryStreamName: tableMap.map[channel].messenger_info,
//                     Records: messenger_info
//                         };
//                     await firehose.putRecordBatch(params).promise();
//                 };
//                 if(map.work_info&&map.work_info.length>0){
//                   var work_info = map.work_info.map((value)=>{
//                       return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                   });
//                     var params = {
//                     DeliveryStreamName: tableMap.map[channel].work_info,
//                     Records: work_info
//                         };
//                     await firehose.putRecordBatch(params).promise();
//                 };
//                 if(map.historical_login_info&&map.historical_login_info.length>0){
//                   var historical_login_info = map.historical_login_info.map((value)=>{
//                       return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                   });
//                     var params = {
//                     DeliveryStreamName: tableMap.map[channel].historical_login_info,
//                     Records: historical_login_info
//                         };
//                     await firehose.putRecordBatch(params).promise();
//                 };
//                 if(map.friends_publish_info&&map.friends_publish_info.length>0){
//                   var friends_publish_info = map.friends_publish_info.map((value)=>{
//                       return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                   });
//                     var params = {
//                     DeliveryStreamName: tableMap.map[channel].friends_publish_info,
//                     Records: friends_publish_info
//                         };
//                     await firehose.putRecordBatch(params).promise();
//                 };
//                 if(map.publish_info&&map.publish_info.length>0){
//                   var publish_info = map.publish_info.map((value)=>{
//                       return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                   });
//                     var params = {
//                     DeliveryStreamName: tableMap.map[channel].publish_info,
//                     Records: publish_info
//                         };
//                     await firehose.putRecordBatch(params).promise();
//                 };
//                  if(map.family_info&&map.family_info.length>0){
//                     var family_info = map.family_info.map((value)=>{
//                       return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                     });
//                     var params = {
//                     DeliveryStreamName: tableMap.map[channel].family_info,
//                     Records: family_info
//                         };
//                     await firehose.putRecordBatch(params).promise();
//                 };
//                 if(map.item){
//                     var recordlist=[];
//                     recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))});
//                     var params = {
//                     DeliveryStreamName: tableMap.map[channel].main,
//                     Records: recordlist
//                         };
//                     await firehose.putRecordBatch(params).promise();
//                 };
//                 // console.log("send2Firehose_channel20",map);
//                 break;   
//             case "40":
//                 if(client_id=='0'||!client_id){
//                     if(map.risk_items&&map.risk_items.length>0){
//                     var risk_items = map.risk_items.map((value)=>{
//                           return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                     });
//                     var params = {
//                     DeliveryStreamName: tableMap.map[channel][0].risk_items,
//                     Records: risk_items
//                         };
//                     await firehose.putRecordBatch(params).promise();
//                     };
//                     if(map.risk_details&&map.risk_details.length>0){
//                       var risk_details = map.risk_details.map((value)=>{
//                           return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                       });
//                         var params = {
//                         DeliveryStreamName: tableMap.map[channel][0].risk_details,
//                         Records: risk_details
//                             };
//                         await firehose.putRecordBatch(params).promise();
//                     };
//                     if(map.risk_detail&&map.risk_detail.length>0){
//                       var risk_detail = map.risk_detail.map((value)=>{
//                           return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                       });
//                         var params = {
//                             DeliveryStreamName: tableMap.map[channel][0].risk_detail,
//                             Records: risk_detail
//                             };
//                         await firehose.putRecordBatch(params).promise();
//                     };
//                     if(map.item){
//                         var recordlist=[];
//                         recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
//                         var params = {
//                             DeliveryStreamName: tableMap.map[channel][0].main,
//                             Records: recordlist
//                             };
//                         await firehose.putRecordBatch(params).promise();
//                     }; 
//                 }else if(client_id=='2'){
//                     if(map.risk_items&&map.risk_items.length>0){
//                     var risk_items = map.risk_items.map((value)=>{
//                           return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                     });
//                     var params = {
//                     DeliveryStreamName: tableMap.map[channel][2].risk_items,
//                     Records: risk_items
//                         };
//                     await firehose.putRecordBatch(params).promise();
//                     };
//                     if(map.risk_detail&&map.risk_detail.length>0){
//                       var risk_detail = map.risk_detail.map((value)=>{
//                           return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                       });
//                         var params = {
//                             DeliveryStreamName: tableMap.map[channel][2].risk_detail,
//                             Records: risk_detail
//                             };
//                         await firehose.putRecordBatch(params).promise();
//                     };
//                     if(map.frequency_detail_list&&map.frequency_detail_list.length>0){
//                       var frequency_detail_list = map.frequency_detail_list.map((value)=>{
//                           return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                       });
//                         var params = {
//                             DeliveryStreamName: tableMap.map[channel][2].frequency_detail_list,
//                             Records: frequency_detail_list
//                             };
//                         await firehose.putRecordBatch(params).promise();
//                     };
//                     if(map.platform_detail_dimension&&map.platform_detail_dimension.length>0){
//                       var platform_detail_dimension = map.platform_detail_dimension.map((value)=>{
//                           return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                       });
//                         var params = {
//                             DeliveryStreamName: tableMap.map[channel][2].platform_detail_dimension,
//                             Records: platform_detail_dimension
//                             };
//                         await firehose.putRecordBatch(params).promise();
//                     };
//                     if(map.platform_detail&&map.platform_detail.length>0){
//                       var platform_detail = map.platform_detail.map((value)=>{
//                           return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                       });
//                         var params = {
//                             DeliveryStreamName: tableMap.map[channel][2].platform_detail,
//                             Records: platform_detail
//                             };
//                         await firehose.putRecordBatch(params).promise();
//                     };
//                     if(map.platform_detail_dimension_detail&&map.platform_detail_dimension_detail.length>0){
//                       var platform_detail_dimension_detail = map.platform_detail_dimension_detail.map((value)=>{
//                           return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                       });
//                         var params = {
//                             DeliveryStreamName: tableMap.map[channel][2].platform_detail_dimension_detail,
//                             Records: platform_detail_dimension_detail
//                             };
//                         await firehose.putRecordBatch(params).promise();
//                     };
//                     if(map.item){
//                         var recordlist=[];
//                         recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
//                         var params = {
//                             DeliveryStreamName: tableMap.map[channel][2].main,
//                             Records: recordlist
//                             };
//                         await firehose.putRecordBatch(params).promise();
//                     }; 
//                 }
                
//                 // console.log("send2Firehose_channel40",map);
//                 break;  
//             case '50':
//                 if(map.item){
//                     var recordlist=[];
//                     recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].main,
//                         Records: recordlist
//                         };
//                     await firehose.putRecordBatch(params).promise();
//                 };
//                 // console.log("send2Firehose_channel=50",map);
//                 break;
//             case '60':
//                 if(map.lastTwoWeeksQueryInfo&&map.lastTwoWeeksQueryInfo.length>0){
//                     var lastTwoWeeksQueryInfo = map.lastTwoWeeksQueryInfo.map((value)=>{
//                       return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                   });
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].lastTwoWeeksQueryInfo,
//                         Records: lastTwoWeeksQueryInfo
//                         };
//                     await firehose.putRecordBatch(params).promise();
//                 };
//                 if(map.statisticCustomerInfolist&&map.statisticCustomerInfolist.length>0){
//                     var statisticCustomerInfolist = map.statisticCustomerInfolist.map((value)=>{
//                       return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                     });
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].statisticCustomerInfo,
//                         Records: statisticCustomerInfolist
//                         };
//                     await firehose.putRecordBatch(params).promise();
//                 };
//                 if(map.item){
//                     var recordlist=[];
//                     recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].main,
//                         Records: recordlist
//                         };
//                     await firehose.putRecordBatch(params).promise();
//                 };
//                 // console.log("send2Firehose_channel=60",map);
//                 break;
//             case '70':
//                 if(map.item){
//                     var recordlist=[];
//                     recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].main,
//                         Records: recordlist
//                         };
//                     await firehose.putRecordBatch(params).promise();
//                 };
//                 // console.log("send2Firehose_channel=70",map);
//                 break;
//              case '80':
//                 if(map.item){
//                     var recordlist=[];
//                     recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].main,
//                         Records: recordlist
//                         };
//                     await firehose.putRecordBatch(params).promise();
//                 };
//                 // console.log("send2Firehose_channel=80",map);
//                 break;
//             case '90':
//                 if(map.item){
//                     var recordlist=[];
//                     recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].main,
//                         Records: recordlist
//                         };
//                     await firehose.putRecordBatch(params).promise();
//                 };
//                 // console.log("send2Firehose_channel=90",map);
//                 break;
//             case '200':
//                 if(map.item){
//                     var recordlist=[];
//                     recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].main,
//                         Records: recordlist
//                         };
//                     await firehose.putRecordBatch(params).promise();
//                 };
//                 // console.log("send2Firehose_channel=200",map);
//                 break;
//             case '210':
//                 if(map.item){
//                     var recordlist=[];
//                     recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].main,
//                         Records: recordlist
//                         };
//                     await firehose.putRecordBatch(params).promise();
//                 };
//                 // console.log("send2Firehose_channel=210",map);
//                 break;
//              case '220':
//                 if(map.item){
//                     var recordlist=[];
//                     recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].main,
//                         Records: recordlist
//                         };
//                     await firehose.putRecordBatch(params).promise();
//                 };
//                 // console.log("send2Firehose_channel=220",map);
//                 break;
//             case '230':
//                 if(map.item){
//                     var recordlist=[];
//                     recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].main,
//                         Records: recordlist
//                         };
//                     await firehose.putRecordBatch(params).promise();
//                 };
//                 // console.log("send2Firehose_channel=230",map);
//                 break;
//             case '240':
//                 if(map.item){
//                     var recordlist=[];
//                     recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].main,
//                         Records: recordlist
//                         };
//                     await firehose.putRecordBatch(params).promise();
//                 };
//                 // console.log("send2Firehose_channel=240",map);
//                 break;
//             case '250':
//                 if(map.detail&&map.detail.length>0){
//                     var detail = map.detail.map((value)=>{
//                       return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                     });
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].detail,
//                         Records: detail
//                         };
//                     await firehose.putRecordBatch(params).promise();
//                 };
//                 if(map.item){
//                     var recordlist=[];
//                     recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].main,
//                         Records: recordlist
//                         };
//                     await firehose.putRecordBatch(params).promise();
//                 };
//                 // console.log("send2Firehose_channel=250",map);
//                 break;
//             case '290':
//                 if(map.detail&&map.detail.length>0){
//                     var detail = map.detail.map((value)=>{
//                       return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                     });
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].detail,
//                         Records: detail
//                         };
//                     await firehose.putRecordBatch(params).promise();
//                 };
//                 if(map.item){
//                     var recordlist=[];
//                     recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].main,
//                         Records: recordlist
//                         };
//                     await firehose.putRecordBatch(params).promise();
//                 };
//                 // console.log("send2Firehose_channel=290",map);
//                 break;
//         }
        
//     }
// }
// async  function sendAll2filehose(relItem){
//     for(var i=0;i<relItem.length;i++){
//         var  recordallList=[];
//         if(relItem[i]){
//             recordallList.push({Data:Buffer.from(JSON.parse(JSON.stringify(relItem[i]), null, 2))})
//             var params = {
//                 DeliveryStreamName: tableMap.map.main,
//                 Records: recordallList
//                 };
//             await firehose.putRecordBatch(params).promise();
//         }
//     }
//     // var recordlist=[];
//     // recordlist.push({Data:Buffer.from(JSON.stringify(relItem, null, 2))})
//     // var params = {
//     //     DeliveryStreamName: tableMap.map.main,
//     //     Records: recordlist
//     //     };
//     // await firehose.putRecordBatch(params).promise();
//     // var recordlist_all=[];
//     // relItem.map(value=>{
//     //     if (value !== "" && value != undefined) {
//     //         recordlist_all.push({Data:Buffer.from(JSON.stringify(value, null, 2))});
//     //     }
//     //     return null;
//     // })
//     //     // recordlist.push({Data:Buffer.from(JSON.stringify(returnMap[key], null, 2))})
//     // var recordlist=[];
//     // for(var a=0;a<recordlist_all.length;a++){
//     //     if(a==0){
//     //         var list_child=[];
//     //         var recordlist=[];
//     //         list_child.push(recordlist_all[0])
//     //     }else{
//     //         if(a%100==0){
//     //             list_child.push(recordlist_all[a])
//     //             recordlist.push(list_child);
//     //             list_child=[]
//     //         }else{
//     //             list_child.push(recordlist_all[a])
//     //         }
//     //     }
//     //     if(a==recordlist_all.length-1&&list_child.length>0){
//     //         recordlist.push(list_child);
//     //     }
//     // }
//     // for(var i=0;i<recordlist.length;i++){
//     //     var params = {
//     //         DeliveryStreamName: tableMap.map.main,
//     //         Records: recordlist[i]
//     //     }
//     //     console.log(recordlist[i])
//     //     await firehose.putRecordBatch(params).promise();
//     // }
// }

// module.exports = {
//  send2filehose,
//  sendAll2filehose
// };

// // module.exports.PrintNearestStore = async function(session, lat, lon) {
// //     await PrintNearestStore(session, lat, lon);
// // }

// // var PrintNearestStore = async function(session, lat, lon) {
// // ...
// // }