const AWS = require('aws-sdk');
// var dynamodb = new AWS.DynamoDB({"accessKeyId ":"AKIA4OO3YD6F6H3BAHEZ","secretAccessKey":"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","region":"ap-southeast-1"});
// var likenames={ 'id':"11111",
//                 "hometown":"Kota Banjar",
//                 "birthdate":null,
//                 "birthyear":null,
//                 "gender":"Perempuan",
//                 "friendsnum":"119",
//                 "language":"Bahasa Sunda dan Bahasa Jawa",
//                 "political_trend":"No koment",
//                 "relationshipstatus":"Menikah",
//                 "blood_type":null,
//                 "currentcity":"Kota Bogor",
//                 "nickname":null,
//                 "religion_trend":null,
//                 "mobilephones":"Verifikasi +62899-3081-586|812-2004-0195|896-6375-1125",
//             };
// var b= AWS.DynamoDB.Converter.marshall(likenames);
// console.log(b)
//  var params = {
//   RequestItems: {
//    "thirdparty_tongdun_ktp": [
//        {
//       PutRequest: {
//        Item: b
//       }
//      }
//     ]
//   }
//  };
 // dynamodb.batchWriteItem(params, function(err, data) {
 //   if (err) console.log(err, err.stack); // an error occurred
 //   else     console.log(data);           // successful response
 //   /*
 //   data = {
 //   }
 //   */
 // })
  const firehose = new AWS.Firehose({"accessKeyId ":"AKIA4OO3YD6F6H3BAHEZ","secretAccessKey":"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","region":"ap-southeast-1"});
  var kinesis = new AWS.Kinesis();
  var recordlist=[];
  var map={"id":1000,"year":"2019","month":"11","day":"01","hour":"11'"}
   recordlist.push({Data:Buffer.from(JSON.stringify(map, null, 2))});
   var params = {
       DeliveryStreamName:"hanpeng_partition_table",
       Records: recordlist
   };
   // console.log("send2Firehose_channel10",map);
   //firehose
    firehose.putRecordBatch(params).promise();