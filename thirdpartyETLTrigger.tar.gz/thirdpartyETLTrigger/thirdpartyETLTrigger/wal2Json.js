
function wal2json(wallog){ 
  var list=[];
  wallog.forEach(function(map){
    var jsonlist=  truncate(map);
       list=list.concat(jsonlist)
   });
   return list;
}
function truncate(map){ 
    // console.log(map)
     var jsondata=JSON.parse(map.data);
     var changeList= jsondata.change;
     var returnlist=[];
     for(var j=0;j<changeList.length;j++){
          var change=changeList[j];
          if(change){
            var kind=change.kind;
            var tableNm=change.table;
            var schema=change.schema;
            if ("t_task"==tableNm && "public"==schema && "update"==kind) {
                var issuccess=true;
                // var json="{";
                var rtnmap={};
                var columnvalues= change.columnvalues;
                var columnnames=change.columnnames;
                for(var i=0;i<columnnames.length;i++){
                    //暂时过滤掉440的
                    if((columnnames[i]=="status"&&columnvalues[i]!=40) || (columnnames[i]=="channel"&&columnvalues[i]==440 )){
                        issuccess=!issuccess;
                        break;
                    }
                    rtnmap[columnnames[i]]=columnvalues[i]
                    
                //     if(i==columnnames.length-1){
                //       json+=('\"'+columnnames[i]+'\"'+":"+(columnvalues[i]!=null?'\"'+ columnvalues[i] + '\"':columnvalues[i]));
                //     }else{
                //         if ("response"==columnnames[i]) {
                //              if(columnvalues[i]&&columnvalues[i].substring(0, 1)=="{"){
                //                   json+='\"'+columnnames[i]+'\"'+":"+columnvalues[i]+",";
                //              }else{
                //                  json+='\"'+columnnames[i]+'\"'+":"+(columnvalues[i]!=null?'\"'+columnvalues[i]+'\"':columnvalues[i])+",";
                //              }
                //          }else{
                //              json+='\"'+columnnames[i]+'\"'+":"+(columnvalues[i]!=null?'\"'+columnvalues[i]+'\"':columnvalues[i])+",";
                //          }
                    
                //   }
                }
                if (issuccess) {
                    // json+="}";
                    // returnlist.push(json)
                    returnlist.push(JSON.stringify(rtnmap))
                    // console.log(returnlist)
                    }
            }; 
        }
     }
    // change= JSON.parse(change).change[0];
    return returnlist;
}

module.exports = {
 wal2json
};