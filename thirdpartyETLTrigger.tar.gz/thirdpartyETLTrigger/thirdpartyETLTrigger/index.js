console.log('Loading function');
const pg=require("pg");
var table=require("./json2Tableschema");
var wal2json=require("./wal2Json");
// var firehose=require("./send2Firehose");
var tableMap = require('./tableNm_conf');
const AWS = require('aws-sdk');
const firehose = new AWS.Firehose({"accessKeyId ":"AKIA4OO3YD6F6H3BAHEZ","secretAccessKey":"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","region":"ap-southeast-1"});
var kinesis = new AWS.Kinesis();
const pool = new pg.Pool({  
    user:"lovina",
    // user:"master",
    database:"lovina",
    // postgres
    password:"UFXXExqnXJix9b2eM9Ge",
    // password:"Urmv]A7keYqw~#?9]8k%",
    port:5432,
    host: 'lovina-prod.ct3lmpqmpvcq.ap-southeast-1.rds.amazonaws.com',
    // host: 'lovina-test.ct3lmpqmpvcq.ap-southeast-1.rds.amazonaws.com',
    // 扩展属性
    max:20, // 连接池最大连接数
    idleTimeoutMillis:3000, // 连接最大空闲时间 3s
    });
    
    
    
exports.handler = async function(event, context) {
     try {
          for(var i=0;i<30;i++){
            var sql1="SELECT   *   FROM pg_logical_slot_peek_changes('t_task_slot', null,null,'include-timestamp','1') limit 2000"
            var data = await query(sql1)
            var limitdata=data["rows"]
            if(limitdata.length>0){
              var last_lsn=limitdata[limitdata.length-1].lsn;
              var sql2="SELECT lsn, xid FROM pg_logical_slot_get_changes('t_task_slot','"+ last_lsn+"',NULL) LIMIT 1"
              await query(sql2);
              var jsonList = wal2json.wal2json(limitdata);
              if(jsonList.length>0){
            //   await json2firehose(jsonList);
               //   全量发送给firehose
               await sendAll2filehose(jsonList);
            //   const list =json2firehose(jsonList)
            //   const reqs =send2filehose(list);
            //   await Promise.all(reqs);
              }
            }else{
              break;
            }
          }
    } catch (err) {
      console.error('error', err);
    }
    return ;
    
    
    // const sql="SELECT   *   FROM pg_logical_slot_get_changes('t_task_slot', null,null)";
    // const { rows } = await query(sql);
    // try {
    //   var jsonList = wal2json.wal2json(rows);
    //     if(jsonList.length>0){
    //       json2firehose(jsonList);
    //     //   全量发送给firehose
    //       await sendAll2filehose(jsonList);
    //       const list =json2firehose(jsonList)
    //       const reqs =send2filehose(list);
    //       await Promise.all(reqs);
    //     }
    // } catch (err) {
    //     console.error('error', JSON.stringify(err, null, 2));
    // }
    // return
};

async function query (q) {
      // console.log(q)
      const client = await pool.connect();
      let res;
      try {
        await client.query('BEGIN')
        try {
          res = await client.query(q)
          await client.query('COMMIT')
        } catch (err) {
          await client.query('ROLLBACK')
          throw err
        }
      } finally {
        client.release()
      }
    return res
}


const responseStr=/response":{/;
const responseStr1=/response/;
async  function sendAll2filehose(returnlist){
    // console.log(returnlist)
    if(returnlist){
            var recordlist_all=[];
            recordlist_all= returnlist.map(value=>{
                try{
                    // if(value['id']=="124951880"){
                    //   console.log("结果是------"+returnlist)  
                    // }
                //   console.log(typeof(value))
                //   var jsvalue=JSON.parse(value)
                //   var rtndata=Buffer.from(JSON.stringify(jsvalue, null, 2))
                var rtndata=Buffer.from(value)
                } catch (err) {
                    console.log(value)
                    console.log(err)
                }
                return {Data:rtndata}
            })
            var recordlist=[];
            for(var a=0;a<recordlist_all.length;a++){
                if(a==0){
                    var list_child=[];
                    var recordlist=[];
                    list_child.push(recordlist_all[0])
                }else{
                    if(a%100==0){
                        list_child.push(recordlist_all[a])
                        recordlist.push(list_child);
                        list_child=[]
                    }else{
                        list_child.push(recordlist_all[a])
                    }
                }
                if(a==recordlist_all.length-1&&list_child.length>0){
                    recordlist.push(list_child);
                }
            }
            for(var i=0;i<recordlist.length;i++){
                var params = {
                    DeliveryStreamName: tableMap.map.main,
                    Records: recordlist[i]
                };
                // console.log(params)
                // await data2Firehose(params,tableMap.map.main)
                await firehose.putRecordBatch(params).promise();
               
            }
    }
}
async function data2Firehose(params){
  try {
        let data = await firehose.putRecordBatch(params).promise()
        var failecnt=data["FailedPutCount"]
            if(failecnt>0){
                params.Records=params.Records.slice(params.Records.length-failecnt,params.Records.length)
                await data2Firehose(params)
            }
    } catch(error){
               await data2Firehose(params);
               console.log("error: " + error.message);
    }
}
 function json2firehose(jsonlist){
    var  map={"10":[],"20":[],"40":{"0":[],"2":[]},"50":[],"60":[],"70":[],"80":[],"90":[],"200":[],"210":[],"220":[],"240":[],"250":[],"290":[]};
    if(jsonlist.length>0){
        jsonlist.forEach(function(item,index){
        //验证json 
            try{
                if(item&&item.length>2&&((responseStr1.test(item)&&responseStr.test(item))||!responseStr1.test(item))){
                    item=JSON.parse(item);
                    if(item.customer_id){
                        var senditem=null;
                        if(item.channel=='10'){
                            senditem=json2firehose10(item);
                            map[item.channel].push(senditem);
                        }else if(item.channel=='20'){
                            senditem=json2firehose20(item);
                            map[item.channel].push(senditem);
                        }else if(item.channel=='40'){
                            if(item.client_id=='0'||!item.client_id){
                                senditem=json2firehose40(item);
                                map[item.channel]["0"].push(senditem);
                            }else if(item.client_id=='2'){
                                senditem=json2firehose40_forRepublika(item);
                                map[item.channel]["2"].push(senditem);
                            }
                        }else if(item.channel=='50'){
                            senditem=json2firehose50(item);
                            map[item.channel].push(senditem);
                        }else if(item.channel=='60'){
                            senditem=json2firehose60(item);
                            map[item.channel].push(senditem);
                        }else if(item.channel=='70'){
                            senditem=json2firehose70(item);
                            map[item.channel].push(senditem);
                        }else if(item.channel=='80'){
                            senditem=json2firehose80(item);
                            map[item.channel].push(senditem);
                        }else if(item.channel=='90'){
                            senditem=json2firehose90(item);
                            map[item.channel].push(senditem);
                        }else if(item.channel=='200'){
                           senditem= json2firehose200(item);
                            map[item.channel].push(senditem);
                        }else if(item.channel=='210'){
                            senditem=json2firehose210(item);
                            map[item.channel].push(senditem);
                        }else if(item.channel=='220'){
                            senditem=json2firehose220(item);
                            map[item.channel].push(senditem);
                        }else if(item.channel=='240'){
                            senditem=json2firehose240(item);
                            map[item.channel].push(senditem);
                        }else if(item.channel=='250'){
                            senditem=json2firehose250(item);
                            map[item.channel].push(senditem);
                        }else if(item.channel=='290'){
                            senditem=json2firehose290(item);
                            map[item.channel].push(senditem);
                        }
                        // if(senditem){
                        //   send2filehose(senditem["item"]["channel"],senditem,senditem["item"]["client_id"]);
                        // } 
                      
                    }
                }
            }catch(e){
               console.log(item);
               console.log("logeeeeeeeee",e)
            }   
       })
        return map;
    }
    return null
};
// function a(){

// }
//TONGDUN_KTP(10)
function json2firehose10(item){
    let relItem=JSON.parse(JSON.stringify(item));
    if(item.response&&item.response.data&&item.response.data!="{}"){
        item.identity_code=item.response.data.identity_code;
        item.channel_src=item.response.data.channel_src;
        item.user_mobile=item.response.data.user_mobile;
        item.real_name=item.response.data.real_name;
        item.channel_code=item.response.data.channel_code;
        item.channel_type=item.response.data.channel_type;
        item.message=item.response.message;
        item.task_id=item.response.task_id;
        item.code=item.response.code;
        item.task_data_return_info_ktp_result_wrong_type=item.response.data.task_data.return_info.ktp_result.wrong_type;
        item.task_data_return_info_is_match=item.response.data.task_data.return_info.is_match;
        item.task_data_return_info_phone_is_match=item.response.data.task_data.return_info.phone_is_match;
        delete item.response;
    }
    return item ;
    // firehose.send2filehose(item.channel,item,item.client_id,relItem);
}
//    TONGDUN_FACEBOOK(20)
function json2firehose20(item){
    let relItem=JSON.parse(JSON.stringify(item));
    var returnmap={};
    var thirdparty_id=item.thirdparty_id;
    if(item.response&&item.response.data&&item.response.data!="{}"){
        // var friends_info=item.response.data.task_data.friends_info;
        //friends_info
        if(item.response.data.task_data.friends_info&&item.response.data.task_data.friends_info.length>0){
            returnmap["friends_info"] = item.response.data.task_data.friends_info.map((rs,index) =>{
            rs["customer_id"]=item.customer_id;    
            rs["loan_id"]=item.loan_id;
            rs["create_time"]=item.create_time;  
            rs["query_key"]=item.query_key; 
            rs["thirdparty_id"]=item.thirdparty_id;
            return rs;
            })
        };
        delete  item.response.data.task_data.friends_info;
        //family_info
        if(item.response.data.task_data.family_info&&item.response.data.task_data.family_info.length>0){
             returnmap["family_info"] = item.response.data.task_data.family_info.map((rs,index) =>{
            rs["thirdparty_id"]=item.thirdparty_id;
            rs["customer_id"]=item.customer_id;    
            rs["loan_id"]=item.loan_id;
            rs["create_time"]=item.create_time;  
            rs["query_key"]=item.query_key; 
            return rs;
            })
        };
        delete  item.response.data.task_data.family_info;
        if(item.response.data.task_data.education_info.college_info&&item.response.data.task_data.education_info.college_info.length>0){
            returnmap["education_info_college_info"] = item.response.data.task_data.education_info.college_info.map((rs,index) =>{
            rs["thirdparty_id"]=item.thirdparty_id;
            rs["customer_id"]=item.customer_id;    
            rs["loan_id"]=item.loan_id;
            rs["create_time"]=item.create_time;  
            rs["query_key"]=item.query_key; 
            return rs;
            })
        };
        delete  item.response.data.task_data.education_info.college_info;
        if(item.response.data.task_data.education_info.highschool_info&&item.response.data.task_data.education_info.highschool_info.length>0){
            returnmap["education_info_highschool_info"]= item.response.data.task_data.education_info.highschool_info.map((rs) =>{
            rs["thirdparty_id"]=item.thirdparty_id;
            rs["customer_id"]=item.customer_id;    
            rs["loan_id"]=item.loan_id;
            rs["create_time"]=item.create_time;  
            rs["query_key"]=item.query_key; 
            return rs;
            })
        };
        delete  item.response.data.task_data.education_info.highschool_info;
        if(item.response.data.task_data.messenger_info&&item.response.data.task_data.messenger_info.length>0){
            returnmap["messenger_info"] = item.response.data.task_data.messenger_info.map((rs,index) =>{
            rs["thirdparty_id"]=item.thirdparty_id;
            rs["customer_id"]=item.customer_id;    
            rs["loan_id"]=item.loan_id;
            rs["create_time"]=item.create_time;  
            rs["query_key"]=item.query_key; 
            return rs;
            })
        };
        delete  item.response.data.task_data.messenger_info;
        if(item.response.data.task_data.work_info&&item.response.data.task_data.work_info.length>0){
            returnmap["work_info"]= item.response.data.task_data.work_info.map((rs,index) =>{
            rs["thirdparty_id"]=item.thirdparty_id;
            rs["customer_id"]=item.customer_id;    
            rs["loan_id"]=item.loan_id;
            rs["create_time"]=item.create_time;  
            rs["query_key"]=item.query_key; 
            return rs;
            })
        };
        delete  item.response.data.task_data.work_info;
        if(item.response.data.task_data.historical_login_info&&item.response.data.task_data.historical_login_info.length>0){
            returnmap["historical_login_info"]= item.response.data.task_data.historical_login_info.map((rs,index) =>{
            rs["thirdparty_id"]=item.thirdparty_id;
            rs["customer_id"]=item.customer_id;    
            rs["loan_id"]=item.loan_id;
            rs["create_time"]=item.create_time;  
            rs["query_key"]=item.query_key; 
            return rs;
            })
        };
        delete  item.response.data.task_data.historical_login_info;
        if(item.response.data.task_data.friends_publish_info&&item.response.data.task_data.friends_publish_info.length>0){
            returnmap["friends_publish_info"]= item.response.data.task_data.friends_publish_info.map((rs,index) =>{
            rs["thirdparty_id"]=item.thirdparty_id;
            rs["customer_id"]=item.customer_id;    
            rs["loan_id"]=item.loan_id;
            rs["create_time"]=item.create_time;  
            rs["query_key"]=item.query_key; 
            return rs;
            })
        };
        delete  item.response.data.task_data.friends_publish_info;
        if(item.response.data.task_data.publish_info&&item.response.data.task_data.publish_info.length>0){
            returnmap["publish_info"]= item.response.data.task_data.publish_info.map((rs,index) =>{
            rs["thirdparty_id"]=item.thirdparty_id;
            rs["customer_id"]=item.customer_id;    
            rs["loan_id"]=item.loan_id;
            rs["create_time"]=item.create_time;  
            rs["query_key"]=item.query_key; 
            rs["likenames"]=rs.likenames.toString();
            return rs;
            })
        };
        delete  item.response.data.task_data.publish_info;
        if(item.response.data.task_data.base_info){
           Object.keys(item.response.data.task_data.base_info).forEach(function(key){
               if(key=='mobilephones'||key=='emails'){
                    item.response.data.task_data.base_info[key]=item.response.data.task_data.base_info[key].toString();
                }
           item[key]=item.response.data.task_data.base_info[key];
           });
        };
        if(item.response.data.task_data.payments_info){
            item["payments_info"]=item.response.data.task_data.payments_info+"";
        };
        delete  item.response.data.task_data;
    }
    item={
            ...item,
            ...item.response?item.response={
                ...item.response,
                ...item.response.data?item.response.data:null
            }:null
        }
    delete item.response;
    delete item.data;
    returnmap["item"]=item;
    // console.log("returnmap-------------",returnmap)
    return returnmap;
    // firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
    
}
//    TONGDUN_GUARD(40), client_id is null or client_id='0'
function json2firehose40(item){
    let relItem=JSON.parse(JSON.stringify(item));
    var returnmap={};
    var thirdparty_id=item.thirdparty_id;
    if(item.response&&item.response!="{}"){
        item["success"]=item.response.success;
        // item["id"]=item.response.id;
        //INFOANALYSIS
       if(item.response.result_desc.INFOANALYSIS){
           item["address_detect_true_ip_address"]=item.response.result_desc.INFOANALYSIS.address_detect.true_ip_address;
           item["device_info_error"]=item.response.result_desc.INFOANALYSIS.device_info.error;
           delete item["INFOANALYSIS"];
       } 
       //ANTIFRAUD
       if(item.response.result_desc.ANTIFRAUD){
            item["final_score"]=item.response.result_desc.ANTIFRAUD.final_score;
            item["final_decision"]=item.response.result_desc.ANTIFRAUD.final_decision;
            returnmap["risk_details"]=[];
            returnmap["risk_detail"]=[];
            if(item.response.result_desc.ANTIFRAUD.risk_items&&item.response.result_desc.ANTIFRAUD.risk_items.length>0){
                //risk_items
                 returnmap["risk_items"]=item.response.result_desc.ANTIFRAUD.risk_items.map((value,index)=>{
                      value["customer_id"]=item.customer_id;
                      value["loan_id"]=item.loan_id;
                      value["create_time"]=item.create_time;
                      value["query_key"]=item.query_key;
                      value["thirdparty_id"]=item.thirdparty_id;
                      if(value.risk_detail&&value.risk_detail.length>0){
                          //risk_detail
                           value.risk_detail.map((value2)=>{
                               value2["rule_id"]=value.rule_id;
                               value2["rule_detail_id"]=value.rule_id+"_"+index;
                               value2["customer_id"]=item.customer_id;
                               value2["loan_id"]=item.loan_id;
                               value2["create_time"]=item.create_time;
                               value2["query_key"]=item.query_key;
                               value2["thirdparty_id"]=item.thirdparty_id;
                               if(value2.risk_details&&value2.risk_details.length>0){
                                   //risk_details
                                   value2.risk_details.map((value3)=>{
                                       value3["rule_id"]=value.rule_id;
                                       value3["rule_detail_id"]=value2["rule_detail_id"];
                                       value3["customer_id"]=item.customer_id;
                                       value3["loan_id"]=item.loan_id;
                                       value3["create_time"]=item.create_time;
                                       value3["query_key"]=item.query_key;
                                       value3["thirdparty_id"]=item.thirdparty_id;
                                       if(value3.mh_value&&typeof(value3.mh_value)=='object'){
                                           value3["mh_value"]=value3["mh_value"].toString();
                                        }
                                       returnmap["risk_details"].push(value3);  
                                   })
                               }
                               delete value2.risk_details;
                               returnmap["risk_detail"].push(value2);
                           })
                      }
                      delete value.risk_detail
                      return value;
                })
            }
       }
    }
    delete  item["response"];
    returnmap["item"]=item;
    return returnmap;
    // firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
    
}
//    TONGDUN_KTP_OCR(40) client_id=2
function json2firehose40_forRepublika(item){
    let relItem=JSON.parse(JSON.stringify(item));
    var returnmap={};
    var thirdparty_id=item.thirdparty_id;
    if(item.response&&item.response!="{}"){
        item["success"]=item.response.success;
        // item["id"]=item.response.id;
        //INFOANALYSIS
       if(item.response.result_desc&&item.response.result_desc.INFOANALYSIS){
           item["address_detect_true_ip_address"]=item.response.result_desc.INFOANALYSIS.address_detect.true_ip_address;
           item["device_info_error"]=item.response.result_desc.INFOANALYSIS.device_info.error;
           delete item["INFOANALYSIS"];
       } 
       //ANTIFRAUD
       if(item.response.result_desc&&item.response.result_desc.ANTIFRAUD){
            item["final_score"]=item.response.result_desc.ANTIFRAUD.final_score;
            item["final_decision"]=item.response.result_desc.ANTIFRAUD.final_decision;
            if(item.response.result_desc.ANTIFRAUD.risk_items&&item.response.result_desc.ANTIFRAUD.risk_items.length>0){
                //risk_items
                returnmap["risk_detail"]=[];
                returnmap["frequency_detail_list"]=[];
                returnmap["platform_detail_dimension"]=[];
                returnmap["platform_detail"]=[];
                returnmap["platform_detail_dimension_detail"]=[];
                 returnmap["risk_items"]=item.response.result_desc.ANTIFRAUD.risk_items.map((value,index)=>{
                      value["customer_id"]=item.customer_id;
                      value["loan_id"]=item.loan_id;
                      value["create_time"]=item.create_time;
                      value["query_key"]=item.query_key;
                      value["thirdparty_id"]=item.thirdparty_id;
                      if(value.risk_detail&&value.risk_detail.length>0){
                          //risk_detail
                           value.risk_detail.map((value2)=>{
                               value2["rule_id"]=value.rule_id;
                               value2["rule_detail_id"]=value.rule_id+"_"+index;
                               value2["type"]=value2.type
                               value2["customer_id"]=item.customer_id;
                               value2["loan_id"]=item.loan_id;
                               value2["create_time"]=item.create_time;
                               value2["query_key"]=item.query_key;
                               value2["thirdparty_id"]=item.thirdparty_id;
                               if(value2.frequency_detail_list&&value2.frequency_detail_list.length>0){
                                   //risk_details
                                   value2.frequency_detail_list.map((value3)=>{
                                       value3["rule_id"]=value.rule_id;
                                       value3["rule_detail_id"]=value2["rule_detail_id"];
                                       value3["customer_id"]=item.customer_id;
                                       value3["loan_id"]=item.loan_id;
                                       value3["create_time"]=item.create_time;
                                       value3["query_key"]=item.query_key;
                                       value3["thirdparty_id"]=item.thirdparty_id;
                                       value3["data"]=value3.data?"":value3.data;  
                                       value3["detail"]=value3.detail
                                       returnmap["frequency_detail_list"].push(value3);  
                                   })
                               }
                                if(value2.platform_detail_dimension&&value2.platform_detail_dimension.length>0){
                                   //risk_details
                                   value2.platform_detail_dimension.map((value3,index2)=>{
                                       value3["rule_id"]=value.rule_id;
                                       value3["rule_detail_id"]=value2["rule_detail_id"];
                                       value3["rule_detail_id2"]=value2["rule_detail_id"]+"_"+index2;
                                       value3["customer_id"]=item.customer_id;
                                       value3["loan_id"]=item.loan_id;
                                       value3["create_time"]=item.create_time;
                                       value3["query_key"]=item.query_key;
                                       value3["thirdparty_id"]=item.thirdparty_id;
                                       if(value3.detail&&value3.detail.length>0){
                                           //risk_details
                                           value3.detail.map((value4)=>{
                                               value4["rule_id"]=value.rule_id;
                                               value4["rule_detail_id"]=value2["rule_detail_id"];
                                               value4["rule_detail_id2"]=value3["rule_detail_id2"];
                                               value4["customer_id"]=item.customer_id;
                                               value4["loan_id"]=item.loan_id;
                                               value4["create_time"]=item.create_time;
                                               value4["query_key"]=item.query_key;
                                               value4["thirdparty_id"]=item.thirdparty_id;
                                               returnmap["platform_detail_dimension_detail"].push(value4);
                                               
                                           })
                                       }
                                       delete value3.detail;
                                       returnmap["platform_detail_dimension"].push(value3);
                                   })
                               }
                                if(value2.platform_detail&&value2.platform_detail.length>0){
                                   //platform_detail
                                   value2.platform_detail.map((value3)=>{
                                       value3["rule_id"]=value.rule_id;
                                       value3["rule_detail_id"]=value2["rule_detail_id"];
                                       value3["customer_id"]=item.customer_id;
                                       value3["loan_id"]=item.loan_id;
                                       value3["create_time"]=item.create_time;
                                       value3["query_key"]=item.query_key;
                                       value3["thirdparty_id"]=item.thirdparty_id;
                                       returnmap["platform_detail"].push(value3);
                                   })
                               }
                               delete value2.risk_details;
                               delete value2.platform_detail_dimension;
                               delete value2.platform_detail;
                               delete value2.frequency_detail_list;
                               returnmap["risk_detail"].push(value2);
                           })
                      }
                      delete value.risk_detail
                      return value;
                })
            }
       }
    }
    delete  item["response"];
    returnmap["item"]=item;
    return returnmap;
    // firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
}
//    TONGDUN_KTP_OCR(50)
function json2firehose50(item){
     let relItem=JSON.parse(JSON.stringify(item));
     var returnmap={};
     if(item.response&&item.response.data&&item.response.data!="{}"){
         returnmap["item"] ={
                ...item.response?item.response:null,
                ...item.response.data?item.response.data:null,
                ...item.response.data.task_data?item.response.data.task_data={
                    ...item.response.data.task_data.other?item.response.data.task_data.other:null,
                    ...item.response.data.task_data.profile?item.response.data.task_data.profile:null,
                    ...item.response.data.task_data.return_info?item.response.data.task_data.return_info={
                        ...item.response.data.task_data.return_info,
                        ...item.response.data.task_data.return_info.ktp_result?item.response.data.task_data.return_info.ktp_result:null
                    }:null,
                }:null,
            }
        delete item["response"];
        delete item["data"];
        delete item["task_data"];
        delete item["other"];
        delete item["profile"];
        delete item["return_info"];
        delete item["ktp_result"];
    }
    returnmap['item']={
       ...item,
       ...returnmap['item']
    }
    return returnmap;
    // firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
}
//    ADVANCE_AI_MULTI_PLATFORM(60),
function json2firehose60(item){
     let relItem=JSON.parse(JSON.stringify(item));
    var returnmap={};
    if(item.response&&item.response.data&&item.response.data!="{}"){
        if(item.response.data&&item.response.data.statistics){
            if(item.response.data.statistics.statisticCustomerInfo&&item.response.data.statistics.statisticCustomerInfo.length>0){
                returnmap["statisticCustomerInfolist"]=item.response.data.statistics.statisticCustomerInfo.map((value)=>{
                    value["customer_id"]=item.customer_id;
                    value["loan_id"]=item.loan_id;
                    value["create_time"]=item.create_time;
                    value["query_key"]=item.query_key;
                    value["thirdparty_id"]=item.thirdparty_id;
                    return  value;
                })
            }
            if(item.response.data.statistics.lastTwoWeeksQueryInfo&&item.response.data.statistics.lastTwoWeeksQueryInfo.length>0){
                returnmap["lastTwoWeeksQueryInfo"]=item.response.data.statistics.lastTwoWeeksQueryInfo.map((value)=>{
                    value["customer_id"]=item.customer_id;
                    value["loan_id"]=item.loan_id;
                    value["create_time"]=item.create_time;
                    value["query_key"]=item.query_key;
                    value["thirdparty_id"]=item.thirdparty_id;
                    return  value;
                })
            }
            if(item.response.data.records&&item.response.data.records.length>0){
                returnmap["records"]=item.response.data.records.map((value)=>{
                    value["customer_id"]=item.customer_id;
                    value["loan_id"]=item.loan_id;
                    value["create_time"]=item.create_time;
                    value["query_key"]=item.query_key;
                    value["thirdparty_id"]=item.thirdparty_id;
                    value["queryDates"]=value.queryDates.toString();
                    return  value;
                })
            }
        }  
    }
    delete item["response"]["data"];
    item ={
            ...item,
            ...item.response?item.response:null,
        }
    delete item["response"];
    delete item["data"];
    returnmap['item']=item;
    return returnmap;
    // console.log("channel60",returnmap);
  // firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
}
//    IZI_PHONE_VERIFY(70)
function json2firehose70(item){
     let relItem=JSON.parse(JSON.stringify(item));
    var returnmap={};
    returnmap['item']={};
    if(item.response&&item.response!="{}"){
        returnmap['item']["res_status"]=item.response.status;
        returnmap['item']["message"]=item.response.message;
    }
    delete item["response"];
    returnmap['item'] ={
            ...returnmap['item'],
            ...item,
        }
    return returnmap;    
    // console.log("channel70",returnmap);
  // firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
}
//    IZI_PHONE_AGE(80)
function json2firehose80(item){
     let relItem=JSON.parse(JSON.stringify(item));
    var returnmap={};
    returnmap['item']={};
    if(item.response&&item.response!="{}"){
        returnmap['item']["res_status"]=item.response.status;
        returnmap['item']["message"]="";
        if(item.response.message){
            if(typeof(item.response.message)=='object'){
              returnmap['item']={
                  ...returnmap['item'],
                  ...item.response.message
              }
            }else{
                returnmap['item']["message"]=item.response.message;
            }
        }
    }
    delete item["response"];
    returnmap['item'] ={
            ...returnmap['item'],
            ...item,
        }
    console.log("channel80",returnmap);
    return returnmap;
  // firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
}
//    IZI_PHONE_WHATSAPP(90)
function json2firehose90(item){
     let relItem=JSON.parse(JSON.stringify(item));
    var returnmap={};
    returnmap['item']={};
    if(item.response&&item.response!="{}"){
        returnmap['item']["res_status"]=item.response.status;
       if(item.response.message){
            if(typeof(item.response.message)=='object'){
              returnmap['item']={
                  ...returnmap['item'],
                  ...item.response.message
              }
            }else{
                returnmap['item']["message"]=item.response.message;
            }
        }
    }
    delete item["response"];
    returnmap['item'] ={
            ...returnmap['item'],
            ...item,
        }
    return returnmap;
    // firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
}
//   KTP_MULTI_PLATFORM_DETECTION(200),
function json2firehose200(item){
     let relItem=JSON.parse(JSON.stringify(item));
    var returnmap={};
    returnmap['item']=item;
    if(item.response&&item.response!="{}"){
        returnmap['item']["res_status"]=item.response.status;
        if(item.response.message){
            if(typeof(item.response.message)=='object'){
              returnmap['item']={
                  ...returnmap['item'],
                  ...item.response.message
              }
            }else{
                returnmap['item']["message"]=item.response.message;
            }
        }
    }
    delete  returnmap['item'].response;
    return returnmap;
    // firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
}
//    KTP_MULTI_PLATFORM_DETECTION_BRIEF_CHECK(210),
function json2firehose210(item){
     let relItem=JSON.parse(JSON.stringify(item));
    var returnmap={};
    returnmap['item']={};
    if(item.response&&item.response!="{}"){
        returnmap['item']["res_status"]=item.response.status;
        returnmap['item']["message"]="";
        if(item.response.message){
            if(typeof(item.response.message)=='object'){
              returnmap['item']={
                  ...returnmap['item'],
                  ...item.response.message
              }
            }else{
                returnmap['item']["message"]=item.response.message;
            }
        }
    }
    delete item["response"];
    returnmap['item'] ={
            ...returnmap['item'],
            ...item,
        }
    // console.log(returnmap)    
    return returnmap;
    // firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
}
//    IZI_BLACK_CHECK(220),
function json2firehose220(item){
     let relItem=JSON.parse(JSON.stringify(item));
    var returnmap={};
    returnmap['item']=item;
    if(item.response&&item.response!="{}"){
        returnmap['item']["res_status"]=item.response.status;
        returnmap['item']['message']=item.response.message;
    }
    delete returnmap['item'].response
    return returnmap;
    // firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
}
//    IDENTITY_CHECK(230),
function json2firehose230(item){
    let relItem=JSON.parse(JSON.stringify(item));
    var returnmap={};
    returnmap['item']=item;
    if(item.response&&item.response!="{}"){
        returnmap['item']["res_status"]=item.response.status;
        if(item.response.message){
             delete item.response.message.id;
             returnmap['item']={
                ...returnmap['item'],
                ...item.response.message
             }
        }
    }
    delete  returnmap['item'].response;
    // console.log(returnmap)    
    return returnmap;
    // firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
}
//    YITU_FACE_VERIFY(240),
function json2firehose240(item){
    let relItem=JSON.parse(JSON.stringify(item));
    var returnmap={};
    returnmap['item']=item;
    if(item.response&&item.response!="{}"){
        returnmap['item']={
            ...returnmap['item'],
            ...item.response,
            ...item.response.query_image_package_result?item.response.query_image_package_result:null,
        }
    }
    delete  returnmap['item'].response;
    delete  returnmap['item'].query_image_package_result;
    returnmap['item'].query_image_contents=returnmap['item'].query_image_contents?returnmap['item'].query_image_contents.toString():null;
    // console.log(returnmap)    
    return returnmap;
    // firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
}
//    STI_MOBILE_CHECK(250),
function json2firehose250(item){
    let relItem=JSON.parse(JSON.stringify(item));
    var returnmap={};
    returnmap['item']=item;
    if(item.response&&item.response!="{}"){
        returnmap['detail']=returnmap['item'].response.list;
        returnmap['item']={
            ...returnmap['item'],
            ...item.response.data?item.response.data:null,
            ...item.response.result?item.response.result:null,
        }
         returnmap['detail']=returnmap['detail'].map((value)=>{
            value["customer_id"]=item.customer_id;
            value["loan_id"]=item.loan_id;
            value["create_time"]=item.create_time;
            value["query_key"]=item.query_key;
            value["thirdparty_id"]=item.thirdparty_id;
            return value;
        })
    }
    delete  returnmap['item'].response;
    // console.log(returnmap)    
    return returnmap;
    // firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
}
function json2firehose290(item){
     let relItem=JSON.parse(JSON.stringify(item));
    var returnmap={};
    returnmap['item']=item;
    if(item.response&&item.response!="{}"){
        returnmap['detail']=returnmap['item'].response.reportDetailList;
        returnmap['item']['res_id']=returnmap['item'].response.id;
        returnmap['item']={
            ...returnmap['item'],
            ...item.response
        }
        returnmap['detail']=returnmap['detail'].map((value)=>{
            value["customer_id"]=item.customer_id;
            value["loan_id"]=item.loan_id;
            value["create_time"]=item.create_time;
            value["query_key"]=item.query_key;
            value["thirdparty_id"]=item.thirdparty_id;
            return value;
        })
    }
    delete  returnmap['item'].response;
    delete  returnmap['item'].reportDetailList;
    // console.log(returnmap)  
    return returnmap;
    // firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
}
function verify_json(jsonContent){
    if(jsonContent.length>1
        &&(jsonContent[0]=="{"||jsonContent[0]=="[")
        &&(jsonContent[jsonContent.length-1]=="}"||jsonContent[jsonContent.length-1]=="]")){
        return true;
    }
    return false;
}

// async  function send2filehose(channel,map,client_id){
//     // console.log("send2Firehose_id____",map['item'].id);
//     const promises = [];
//     if(channel){
//         switch (channel){
//             case "10":
//                 var recordlist=[];
//                 recordlist.push({Data:Buffer.from(JSON.stringify(map, null, 2))});
//                 var params = {
//                     DeliveryStreamName: tableMap.map[channel].main,
//                     Records: recordlist
//                 };
//                 // await firehose.putRecordBatch(params);
//                  promises.push(firehose.putRecordBatch(params));
//                 break;
//             case "20":
//                 if(map.friends_info&&map.friends_info.length>0){
//                   var friends_info = map.friends_info.map((value)=>{
//                       return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                   });
//                     var params = {
//                     DeliveryStreamName: tableMap.map[channel].friends_info,
//                     Records: friends_info
//                         };
//                     promises.push(firehose.putRecordBatch(params));
//                 };
//                 if(map.education_info_college_info&&map.education_info_college_info.length>0){
//                   var education_info_college_info = map.education_info_college_info.map((value)=>{
//                       return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                   });
//                     var params = {
//                     DeliveryStreamName: tableMap.map[channel].education_info_college_info,
//                     Records: education_info_college_info
//                         };
//                     promises.push(firehose.putRecordBatch(params));
//                 };
//                 if(map.education_info_highschool_info&&map.education_info_highschool_info.length>0){
//                   var education_info_highschool_info = map.education_info_highschool_info.map((value)=>{
//                       return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                   });
//                     var params = {
//                     DeliveryStreamName: tableMap.map[channel].education_info_highschool_info,
//                     Records: education_info_highschool_info
//                         };
//                      promises.push(firehose.putRecordBatch(params));
//                 };
//                 if(map.messenger_info&&map.messenger_info.length>0){
//                   var messenger_info = map.messenger_info.map((value)=>{
//                       return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                   });
//                     var params = {
//                     DeliveryStreamName: tableMap.map[channel].messenger_info,
//                     Records: messenger_info
//                         };
//                      promises.push(firehose.putRecordBatch(params));
//                 };
//                 if(map.work_info&&map.work_info.length>0){
//                   var work_info = map.work_info.map((value)=>{
//                       return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                   });
//                     var params = {
//                     DeliveryStreamName: tableMap.map[channel].work_info,
//                     Records: work_info
//                         };
//                      promises.push(firehose.putRecordBatch(params));
//                 };
//                 if(map.historical_login_info&&map.historical_login_info.length>0){
//                   var historical_login_info = map.historical_login_info.map((value)=>{
//                       return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                   });
//                     var params = {
//                     DeliveryStreamName: tableMap.map[channel].historical_login_info,
//                     Records: historical_login_info
//                         };
//                      promises.push(firehose.putRecordBatch(params));
//                 };
//                 if(map.friends_publish_info&&map.friends_publish_info.length>0){
//                   var friends_publish_info = map.friends_publish_info.map((value)=>{
//                       return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                   });
//                     var params = {
//                     DeliveryStreamName: tableMap.map[channel].friends_publish_info,
//                     Records: friends_publish_info
//                         };
//                      promises.push(firehose.putRecordBatch(params));
//                 };
//                 if(map.publish_info&&map.publish_info.length>0){
//                   var publish_info = map.publish_info.map((value)=>{
//                       return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                   });
//                     var params = {
//                     DeliveryStreamName: tableMap.map[channel].publish_info,
//                     Records: publish_info
//                         };
//                      promises.push(firehose.putRecordBatch(params));
//                 };
//                  if(map.family_info&&map.family_info.length>0){
//                     var family_info = map.family_info.map((value)=>{
//                       return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                     });
//                     var params = {
//                     DeliveryStreamName: tableMap.map[channel].family_info,
//                     Records: family_info
//                         };
//                     promises.push(firehose.putRecordBatch(params));
//                 };
//                 if(map.item){
//                     var recordlist=[];
//                     recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))});
//                     var params = {
//                     DeliveryStreamName: tableMap.map[channel].main,
//                     Records: recordlist
//                         };
//                     promises.push(firehose.putRecordBatch(params));
//                 };
//                 // console.log("send2Firehose_channel20",map);
//                 break;   
//             case "40":
//                 if(client_id=='0'||!client_id){
//                     if(map.risk_items&&map.risk_items.length>0){
//                     var risk_items = map.risk_items.map((value)=>{
//                           return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                     });
//                     var params = {
//                     DeliveryStreamName: tableMap.map[channel][0].risk_items,
//                     Records: risk_items
//                         };
//                     promises.push(firehose.putRecordBatch(params));
//                     };
//                     if(map.risk_details&&map.risk_details.length>0){
//                       var risk_details = map.risk_details.map((value)=>{
//                           return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                       });
//                         var params = {
//                         DeliveryStreamName: tableMap.map[channel][0].risk_details,
//                         Records: risk_details
//                             };
//                      promises.push(firehose.putRecordBatch(params));
//                     };
//                     if(map.risk_detail&&map.risk_detail.length>0){
//                       var risk_detail = map.risk_detail.map((value)=>{
//                           return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                       });
//                         var params = {
//                             DeliveryStreamName: tableMap.map[channel][0].risk_detail,
//                             Records: risk_detail
//                             };
//                       promises.push(firehose.putRecordBatch(params));
//                     };
//                     if(map.item){
//                         var recordlist=[];
//                         recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
//                         var params = {
//                             DeliveryStreamName: tableMap.map[channel][0].main,
//                             Records: recordlist
//                             };
//                       promises.push(firehose.putRecordBatch(params));
//                     }; 
//                 }else if(client_id=='2'){
//                     if(map.risk_items&&map.risk_items.length>0){
//                         var risk_items = map.risk_items.map((value)=>{
//                               return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                         });
//                         var params = {
//                         DeliveryStreamName: tableMap.map[channel][2].risk_items,
//                         Records: risk_items
//                             };
//                         promises.push(firehose.putRecordBatch(params));
//                     };
//                     if(map.risk_detail&&map.risk_detail.length>0){
//                       var risk_detail = map.risk_detail.map((value)=>{
//                           return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                       });
//                         var params = {
//                             DeliveryStreamName: tableMap.map[channel][2].risk_detail,
//                             Records: risk_detail
//                             };
//                         promises.push(firehose.putRecordBatch(params));
//                     };
//                     if(map.frequency_detail_list&&map.frequency_detail_list.length>0){
//                       var frequency_detail_list = map.frequency_detail_list.map((value)=>{
//                           return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                       });
//                         var params = {
//                             DeliveryStreamName: tableMap.map[channel][2].frequency_detail_list,
//                             Records: frequency_detail_list
//                             };
//                          promises.push(firehose.putRecordBatch(params));
//                     };
//                     if(map.platform_detail_dimension&&map.platform_detail_dimension.length>0){
//                       var platform_detail_dimension = map.platform_detail_dimension.map((value)=>{
//                           return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                       });
//                         var params = {
//                             DeliveryStreamName: tableMap.map[channel][2].platform_detail_dimension,
//                             Records: platform_detail_dimension
//                             };
//                          promises.push(firehose.putRecordBatch(params));
//                     };
//                     if(map.platform_detail&&map.platform_detail.length>0){
//                       var platform_detail = map.platform_detail.map((value)=>{
//                           return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                       });
//                         var params = {
//                             DeliveryStreamName: tableMap.map[channel][2].platform_detail,
//                             Records: platform_detail
//                             };
//                          promises.push(firehose.putRecordBatch(params));
//                     };
//                     if(map.platform_detail_dimension_detail&&map.platform_detail_dimension_detail.length>0){
//                       var platform_detail_dimension_detail = map.platform_detail_dimension_detail.map((value)=>{
//                           return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                       });
//                         var params = {
//                             DeliveryStreamName: tableMap.map[channel][2].platform_detail_dimension_detail,
//                             Records: platform_detail_dimension_detail
//                             };
//                          promises.push(firehose.putRecordBatch(params));
//                     };
//                     if(map.item){
//                         var recordlist=[];
//                         recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
//                         var params = {
//                             DeliveryStreamName: tableMap.map[channel][2].main,
//                             Records: recordlist
//                             };
//                          promises.push(firehose.putRecordBatch(params));
//                     }; 
//                 }
                
//                 // console.log("send2Firehose_channel40",map);
//                 break;  
//             case '50':
//                 if(map.item){
//                     var recordlist=[];
//                     recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].main,
//                         Records: recordlist
//                         };
//                      promises.push(firehose.putRecordBatch(params));
//                 };
//                 // console.log("send2Firehose_channel=50",map);
//                 break;
//             case '60':
//                 if(map.lastTwoWeeksQueryInfo&&map.lastTwoWeeksQueryInfo.length>0){
//                     var lastTwoWeeksQueryInfo = map.lastTwoWeeksQueryInfo.map((value)=>{
//                       return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                   });
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].lastTwoWeeksQueryInfo,
//                         Records: lastTwoWeeksQueryInfo
//                         };
//                      promises.push(firehose.putRecordBatch(params));
//                 };
//                 if(map.statisticCustomerInfolist&&map.statisticCustomerInfolist.length>0){
//                     var statisticCustomerInfolist = map.statisticCustomerInfolist.map((value)=>{
//                       return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                     });
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].statisticCustomerInfo,
//                         Records: statisticCustomerInfolist
//                         };
//                      promises.push(firehose.putRecordBatch(params));
//                 };
//                 if(map.item){
//                     var recordlist=[];
//                     recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].main,
//                         Records: recordlist
//                         };
//                      promises.push(firehose.putRecordBatch(params));
//                 };
//                 // console.log("send2Firehose_channel=60",map);
//                 break;
//             case '70':
//                 if(map.item){
//                     var recordlist=[];
//                     recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].main,
//                         Records: recordlist
//                         };
//                      promises.push(firehose.putRecordBatch(params));
//                 };
//                 // console.log("send2Firehose_channel=70",map);
//                 break;
//              case '80':
//                 if(map.item){
//                     var recordlist=[];
//                     recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].main,
//                         Records: recordlist
//                         };
//                      promises.push(firehose.putRecordBatch(params));
//                 };
//                 // console.log("send2Firehose_channel=80",map);
//                 break;
//             case '90':
//                 if(map.item){
//                     var recordlist=[];
//                     recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].main,
//                         Records: recordlist
//                         };
//                      promises.push(firehose.putRecordBatch(params));
//                 };
//                 // console.log("send2Firehose_channel=90",map);
//                 break;
//             case '200':
//                 if(map.item){
//                     var recordlist=[];
//                     recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].main,
//                         Records: recordlist
//                         };
//                      promises.push(firehose.putRecordBatch(params));
//                 };
//                 // console.log("send2Firehose_channel=200",map);
//                 break;
//             case '210':
//                 if(map.item){
//                     var recordlist=[];
//                     recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].main,
//                         Records: recordlist
//                         };
//                     promises.push(firehose.putRecordBatch(params));
//                 };
//                 // console.log("send2Firehose_channel=210",map);
//                 break;
//              case '220':
//                 if(map.item){
//                     var recordlist=[];
//                     recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].main,
//                         Records: recordlist
//                         };
//                      promises.push(firehose.putRecordBatch(params));
//                 };
//                 // console.log("send2Firehose_channel=220",map);
//                 break;
//             case '230':
//                 if(map.item){
//                     var recordlist=[];
//                     recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].main,
//                         Records: recordlist
//                         };
//                      promises.push(firehose.putRecordBatch(params));
//                 };
//                 // console.log("send2Firehose_channel=230",map);
//                 break;
//             case '240':
//                 if(map.item){
//                     var recordlist=[];
//                     recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].main,
//                         Records: recordlist
//                         };
//                      promises.push(firehose.putRecordBatch(params));
//                 };
//                 // console.log("send2Firehose_channel=240",map);
//                 break;
//             case '250':
//                 if(map.detail&&map.detail.length>0){
//                     var detail = map.detail.map((value)=>{
//                       return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                     });
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].detail,
//                         Records: detail
//                         };
//                   promises.push(firehose.putRecordBatch(params));
//                 };
//                 if(map.item){
//                     var recordlist=[];
//                     recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].main,
//                         Records: recordlist
//                         };
//                      promises.push(firehose.putRecordBatch(params));
//                 };
//                 // console.log("send2Firehose_channel=250",map);
//                 break;
//             case '290':
//                 if(map.detail&&map.detail.length>0){
//                     var detail = map.detail.map((value)=>{
//                       return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
//                     });
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].detail,
//                         Records: detail
//                         };
//                     promises.push(firehose.putRecordBatch(params));
//                 };
//                 if(map.item){
//                     var recordlist=[];
//                     recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
//                     var params = {
//                         DeliveryStreamName: tableMap.map[channel].main,
//                         Records: recordlist
//                         };
//                     promises.push(firehose.putRecordBatch(params));
//                 };
//                 // console.log("send2Firehose_channel=290",map);
//                 break;
//         }
        
//     }
// }

 function send2filehose(channelmap){
    var promises=[];
    for(var channel in channelmap){
        // key="10,20,30,40"
        if(channel){
            switch (channel){
            case "10":
                var recordlist=[];
                recordlist=channelmap[channel].map(value=>{
                   return {Data:Buffer.from(JSON.stringify(value.item, null, 2))}
                }) 
                if(recordlist.length>0){
                      var params = {
                        DeliveryStreamName: tableMap.map[channel].main,
                        Records: recordlist
                    };
                promises.push(firehose.putRecordBatch(params).promise());
                }
                break;
            case "20":
                for(var i=0;i<channelmap[channel].length;i++) {
                    if(channelmap[channel][i].friends_info&&channelmap[channel][i].friends_info.length>0){
                      var friends_info = channelmap[channel][i].friends_info.map((value)=>{
                          return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
                      });
                        var params = {
                        DeliveryStreamName: tableMap.map[channel].friends_info,
                        Records: friends_info
                            };
                        promises.push(firehose.putRecordBatch(params).promise());
                    };
                    if(channelmap[channel][i].education_info_college_info&&channelmap[channel][i].education_info_college_info.length>0){
                      var education_info_college_info = channelmap[channel][i].education_info_college_info.map((value)=>{
                          return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
                      });
                        var params = {
                        DeliveryStreamName: tableMap.map[channel].education_info_college_info,
                        Records: education_info_college_info
                            };
                        promises.push(firehose.putRecordBatch(params).promise());
                    };
                    if(channelmap[channel][i].education_info_highschool_info&&channelmap[channel][i].education_info_highschool_info.length>0){
                      var education_info_highschool_info = channelmap[channel][i].education_info_highschool_info.map((value)=>{
                          return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
                      });
                        var params = {
                        DeliveryStreamName: tableMap.map[channel].education_info_highschool_info,
                        Records: education_info_highschool_info
                            };
                         promises.push(firehose.putRecordBatch(params).promise());
                    };
                    if(channelmap[channel][i].messenger_info&&channelmap[channel][i].messenger_info.length>0){
                      var messenger_info = channelmap[channel][i].messenger_info.map((value)=>{
                          return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
                      });
                        var params = {
                        DeliveryStreamName: tableMap.map[channel].messenger_info,
                        Records: messenger_info
                            };
                         promises.push(firehose.putRecordBatch(params).promise());
                    };
                    if(channelmap[channel][i].work_info&&channelmap[channel][i].work_info.length>0){
                      var work_info = channelmap[channel][i].work_info.map((value)=>{
                          return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
                      });
                        var params = {
                        DeliveryStreamName: tableMap.map[channel].work_info,
                        Records: work_info
                            };
                         promises.push(firehose.putRecordBatch(params).promise());
                    };
                    if(channelmap[channel][i].historical_login_info&&channelmap[channel][i].historical_login_info.length>0){
                      var historical_login_info = channelmap[channel][i].historical_login_info.map((value)=>{
                          return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
                      });
                        var params = {
                        DeliveryStreamName: tableMap.map[channel].historical_login_info,
                        Records: historical_login_info
                            };
                         promises.push(firehose.putRecordBatch(params).promise());
                    };
                    if(channelmap[channel][i].friends_publish_info&&channelmap[channel][i].friends_publish_info.length>0){
                      var friends_publish_info = channelmap[channel][i].friends_publish_info.map((value)=>{
                          return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
                      });
                        var params = {
                        DeliveryStreamName: tableMap.map[channel].friends_publish_info,
                        Records: friends_publish_info
                            };
                         promises.push(firehose.putRecordBatch(params).promise());
                    };
                    if(channelmap[channel][i].publish_info&&channelmap[channel][i].publish_info.length>0){
                      var publish_info = channelmap[channel][i].publish_info.map((value)=>{
                          return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
                      });
                        var params = {
                        DeliveryStreamName: tableMap.map[channel].publish_info,
                        Records: publish_info
                            };
                         promises.push(firehose.putRecordBatch(params).promise());
                    };
                     if(channelmap[channel][i].family_info&&channelmap[channel][i].family_info.length>0){
                        var family_info = channelmap[channel][i].family_info.map((value)=>{
                          return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
                        });
                        var params = {
                        DeliveryStreamName: tableMap.map[channel].family_info,
                        Records: family_info
                            };
                        promises.push(firehose.putRecordBatch(params).promise());
                    };
                    if(channelmap[channel][i].item){
                        var recordlist=[];
                        recordlist.push({Data:Buffer.from(JSON.stringify(channelmap[channel][i].item, null, 2))});
                        if(recordlist.length>0){
                         var params = {
                            DeliveryStreamName: tableMap.map[channel].main,
                            Records: recordlist
                        };
                        promises.push(firehose.putRecordBatch(params).promise());
                        }
                    };
                }
                // console.log("send2Firehose_channel20",map);
            break;
            case "40":
                //client=0
                for(var i=0;i<channelmap[channel]["0"].length;i++) {
                    var record=channelmap[channel]["0"][i];
                    if(record.risk_items&&record.risk_items.length>0){
                    var risk_items = record.risk_items.map((value)=>{
                          return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
                    });
                    var params = {
                    DeliveryStreamName: tableMap.map[channel][0].risk_items,
                    Records: risk_items
                        };
                    promises.push(firehose.putRecordBatch(params).promise());
                    };
                    if(record.risk_details&&record.risk_details.length>0){
                      var risk_details = record.risk_details.map((value)=>{
                          return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
                      });
                        var params = {
                        DeliveryStreamName: tableMap.map[channel][0].risk_details,
                        Records: risk_details
                            };
                     promises.push(firehose.putRecordBatch(params).promise());
                    };
                    if(record.risk_detail&&record.risk_detail.length>0){
                      var risk_detail = record.risk_detail.map((value)=>{
                          return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
                      });
                        var params = {
                            DeliveryStreamName: tableMap.map[channel][0].risk_detail,
                            Records: risk_detail
                            };
                      promises.push(firehose.putRecordBatch(params).promise());
                    };
                    if(record.item){
                        var recordlist=[];
                        recordlist.push({Data:Buffer.from(JSON.stringify(record.item, null, 2))})
                        if(recordlist.length>0){
                        var params = {
                            DeliveryStreamName: tableMap.map[channel][0].main,
                            Records: recordlist
                            };
                         promises.push(firehose.putRecordBatch(params).promise());
                        }
                    }; 
                };
                for(var i=0;i<channelmap[channel]["2"].length;i++) {
                    var map=channelmap[channel]["2"][i];
                   if(map.risk_items&&map.risk_items.length>0){
                        var risk_items = map.risk_items.map((value)=>{
                              return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
                        });
                        var params = {
                        DeliveryStreamName: tableMap.map[channel][2].risk_items,
                        Records: risk_items
                            };
                        promises.push(firehose.putRecordBatch(params).promise());
                    };
                    if(map.risk_detail&&map.risk_detail.length>0){
                      var risk_detail = map.risk_detail.map((value)=>{
                          return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
                      });
                        var params = {
                            DeliveryStreamName: tableMap.map[channel][2].risk_detail,
                            Records: risk_detail
                            };
                        promises.push(firehose.putRecordBatch(params).promise());
                    };
                    if(map.frequency_detail_list&&map.frequency_detail_list.length>0){
                      var frequency_detail_list = map.frequency_detail_list.map((value)=>{
                          return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
                      });
                        var params = {
                            DeliveryStreamName: tableMap.map[channel][2].frequency_detail_list,
                            Records: frequency_detail_list
                            };
                         promises.push(firehose.putRecordBatch(params).promise());
                    };
                    if(map.platform_detail_dimension&&map.platform_detail_dimension.length>0){
                      var platform_detail_dimension = map.platform_detail_dimension.map((value)=>{
                          return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
                      });
                        var params = {
                            DeliveryStreamName: tableMap.map[channel][2].platform_detail_dimension,
                            Records: platform_detail_dimension
                            };
                         promises.push(firehose.putRecordBatch(params).promise());
                    };
                    if(map.platform_detail&&map.platform_detail.length>0){
                      var platform_detail = map.platform_detail.map((value)=>{
                          return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
                      });
                        var params = {
                            DeliveryStreamName: tableMap.map[channel][2].platform_detail,
                            Records: platform_detail
                            };
                         promises.push(firehose.putRecordBatch(params).promise());
                    };
                    if(map.platform_detail_dimension_detail&&map.platform_detail_dimension_detail.length>0){
                      var platform_detail_dimension_detail = map.platform_detail_dimension_detail.map((value)=>{
                          return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
                      });
                        var params = {
                            DeliveryStreamName: tableMap.map[channel][2].platform_detail_dimension_detail,
                            Records: platform_detail_dimension_detail
                            };
                         promises.push(firehose.putRecordBatch(params).promise());
                    };
                    if(map.item){
                        var recordlist=[];
                        recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
                        var params = {
                            DeliveryStreamName: tableMap.map[channel][2].main,
                            Records: recordlist
                            };
                         promises.push(firehose.putRecordBatch(params).promise());
                    }; 
                }
            break;  
            case '50':
                var recordlist=[];
                recordlist=channelmap[channel].map(value=>{
                   return {Data:Buffer.from(JSON.stringify(value.item, null, 2))}
                }) 
                if(recordlist.length>0){
                    var params = {
                        DeliveryStreamName: tableMap.map[channel].main,
                        Records: recordlist
                    };
                    promises.push(firehose.putRecordBatch(params).promise());
                }
            break;
                case '60':
                   for(var i=0;i<channelmap[channel].length;i++) {
                       var map=channelmap[channel][i];
                        if(map.lastTwoWeeksQueryInfo&&map.lastTwoWeeksQueryInfo.length>0){
                            var lastTwoWeeksQueryInfo = map.lastTwoWeeksQueryInfo.map((value)=>{
                              return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
                          });
                            var params = {
                                DeliveryStreamName: tableMap.map[channel].lastTwoWeeksQueryInfo,
                                Records: lastTwoWeeksQueryInfo
                                };
                             promises.push(firehose.putRecordBatch(params).promise());
                        };
                        if(map.statisticCustomerInfolist&&map.statisticCustomerInfolist.length>0){
                            var statisticCustomerInfolist = map.statisticCustomerInfolist.map((value)=>{
                              return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
                            });
                            var params = {
                                DeliveryStreamName: tableMap.map[channel].statisticCustomerInfo,
                                Records: statisticCustomerInfolist
                                };
                             promises.push(firehose.putRecordBatch(params).promise());
                        };
                        if(map.item){
                            var recordlist=[];
                            recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
                            var params = {
                                DeliveryStreamName: tableMap.map[channel].main,
                                Records: recordlist
                                };
                             promises.push(firehose.putRecordBatch(params).promise());
                        };
                   }
            break;
           case '70':
                var recordlist=[];
                recordlist=channelmap[channel].map(value=>{
                   return {Data:Buffer.from(JSON.stringify(value.item, null, 2))}
                }) 
                if(recordlist.length>0){
                    var params = {
                        DeliveryStreamName: tableMap.map[channel].main,
                        Records: recordlist
                    };
                    promises.push(firehose.putRecordBatch(params).promise());
                }
            break;
             case '80':
                var recordlist=[];
                recordlist=channelmap[channel].map(value=>{
                   return {Data:Buffer.from(JSON.stringify(value.item, null, 2))}
                }) 
                if(recordlist.length>0){
                    var params = {
                        DeliveryStreamName: tableMap.map[channel].main,
                        Records: recordlist
                    };
                    promises.push(firehose.putRecordBatch(params).promise());
                }
                // console.log("send2Firehose_channel=80",map);
                break;
            case '90':
                var recordlist=[];
                recordlist=channelmap[channel].map(value=>{
                   return {Data:Buffer.from(JSON.stringify(value.item, null, 2))}
                }) 
                if(recordlist.length>0){
                    var params = {
                        DeliveryStreamName: tableMap.map[channel].main,
                        Records: recordlist
                    };
                    promises.push(firehose.putRecordBatch(params).promise());
                }
                // console.log("send2Firehose_channel=90",map);
                break;
            case '200':
               var recordlist=[];
                recordlist=channelmap[channel].map(value=>{
                   return {Data:Buffer.from(JSON.stringify(value.item, null, 2))}
                }) 
                if(recordlist.length>0){
                    var params = {
                        DeliveryStreamName: tableMap.map[channel].main,
                        Records: recordlist
                    };
                    promises.push(firehose.putRecordBatch(params).promise());
                }
                // console.log("send2Firehose_channel=200",map);
                break;
            case '210':
                var recordlist=[];
                recordlist=channelmap[channel].map(value=>{
                   return {Data:Buffer.from(JSON.stringify(value.item, null, 2))}
                }) 
                if(recordlist.length>0){
                    var params = {
                        DeliveryStreamName: tableMap.map[channel].main,
                        Records: recordlist
                    };
                    promises.push(firehose.putRecordBatch(params).promise());
                }
                // console.log("send2Firehose_channel=210",map);
                break;
             case '220':
                var recordlist=[];
                recordlist=channelmap[channel].map(value=>{
                   return {Data:Buffer.from(JSON.stringify(value.item, null, 2))}
                }) 
                if(recordlist.length>0){
                    var params = {
                        DeliveryStreamName: tableMap.map[channel].main,
                        Records: recordlist
                    };
                    promises.push(firehose.putRecordBatch(params).promise());
                }
                // console.log("send2Firehose_channel=220",map);
                break;
            case '230':
                var recordlist=[];
                recordlist=channelmap[channel].map(value=>{
                   return {Data:Buffer.from(JSON.stringify(value.item, null, 2))}
                }) 
                if(recordlist.length>0){
                    var params = {
                        DeliveryStreamName: tableMap.map[channel].main,
                        Records: recordlist
                    };
                    promises.push(firehose.putRecordBatch(params).promise());
                }
                // console.log("send2Firehose_channel=230",map);
                break;
            case '240':
                var recordlist=[];
                recordlist=channelmap[channel].map(value=>{
                   return {Data:Buffer.from(JSON.stringify(value.item, null, 2))}
                }) 
                if(recordlist.length>0){
                    var params = {
                        DeliveryStreamName: tableMap.map[channel].main,
                        Records: recordlist
                    };
                    promises.push(firehose.putRecordBatch(params).promise());
                }
                break;
             case '250':
                    for(var i=0;i<channelmap[channel].length;i++) {
                       var map=channelmap[channel][i];
                       if(map.detail&&map.detail.length>0){
                        var detail = map.detail.map((value)=>{
                          return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
                        });
                        var params = {
                            DeliveryStreamName: tableMap.map[channel].detail,
                            Records: detail
                            };
                          promises.push(firehose.putRecordBatch(params).promise());
                        };
                        if(map.item){
                            var recordlist=[];
                            recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
                            var params = {
                                DeliveryStreamName: tableMap.map[channel].main,
                                Records: recordlist
                                };
                            promises.push(firehose.putRecordBatch(params).promise());
                        };
                    }
                    break;
            case '290':
                 for(var i=0;i<channelmap[channel].length;i++) {
                    var map=channelmap[channel][i];
                    if(map.detail&&map.detail.length>0){
                    var detail = map.detail.map((value)=>{
                      return  { Data:Buffer.from(JSON.stringify(value, null, 2))};
                    });
                    var params = {
                        DeliveryStreamName: tableMap.map[channel].detail,
                        Records: detail
                        };
                    promises.push(firehose.putRecordBatch(params));
                    };
                    if(map.item){
                        var recordlist=[];
                        recordlist.push({Data:Buffer.from(JSON.stringify(map.item, null, 2))})
                        var params = {
                            DeliveryStreamName: tableMap.map[channel].main,
                            Records: recordlist
                            };
                        promises.push(firehose.putRecordBatch(params).promise());
                    };
                 }
                break;
            }
        }
    }
    return promises;
}