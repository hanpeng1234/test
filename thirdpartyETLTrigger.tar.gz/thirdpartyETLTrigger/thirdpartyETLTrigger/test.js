// var a=[{"a":"b"},{"cd":"d"},{"e":"f"}];
// var b=a.map(function(item){
//     console.log(item);
//     item["a1"]='2222';
//     return  item;
// })
// console.log(b);
// var q={"a":"b"};
var likenames={ 'id':"11111",
                "hometown":"Kota Banjar",
                "birthdate":null,
                "birthyear":null,
                "gender":"Perempuan",
                "friendsnum":"119",
                "language":"Bahasa Sunda dan Bahasa Jawa",
                "political_trend":"No koment",
                "relationshipstatus":"Menikah",
                "blood_type":null,
                "currentcity":"Kota Bogor",
                "nickname":null,
                "religion_trend":"",
                "mobilephones":"Verifikasi +62899-3081-586|812-2004-0195|896-6375-1125",
            };
var likenames2={
    "a":"b",
    "c":"d",
    "e":"f",
};
// Object.keys(likenames).forEach(function(key){
//      if(key=='mobilephones'||key=='emails'){
//          likenames[key]=likenames[key].join("|");
//      }
//      q[key]=likenames[key];
//      console.log(key,likenames[key]);

// });
//  console.log(q)
//  var channel=10;
//  }
// var tableMap = require('./tableNm_conf');
// console.log( tableMap.map["10"].main);
// console.log( tableMap.map["20"].family_info+"_demo")
var a=[
                {
                    "rule_id":"23374771",
                    "score":0,
                    "decision":"Accept",
                    "risk_name":"Borrower_name_same_with_KTP_name",
                    "risk_detail":[
                        {
                            "risk_details":[
                                {
                                    "description":"Borrower's name is same with KTP name",
                                    "hit_rule_type":"Identity verification",
                                    "field_type":"name",
                                    "input_value":"azis hidayat"
                                }
                            ],
                            "type":"mh_detail"
                        }
                    ]
                },{
                    "rule_id":"23374772",
                    "score":0,
                    "decision":"Accept",
                    "risk_name":"Borrower_name_same_with_KTP_name",
                    "risk_detail":[
                        {
                            "risk_details":[
                                {
                                    "description":"Borrower's name is same with KTP name",
                                    "hit_rule_type":"Identity verification",
                                    "field_type":"name",
                                    "input_value":"azis hidayat"
                                },{
                                    "description":"Borrower's name is same with KTP name",
                                    "hit_rule_type":"Identity verification",
                                    "field_type":"name",
                                    "input_value":"azis hidayat"
                                }
                            ],
                            "type":"mh_detail"
                        }
                    ]
                }
            ]
        
// var map={};
// map.list1=[];
// map.list2=[];
// map.list3=[];
// map.list1=a.map((value,index)=>{
//       if(value.risk_detail&&value.risk_detail.length>0){
//           value.risk_detail.map((value2)=>{
//               value2["rule_id"]=value.rule_id;
//               value2["rule_detail_id"]=value.rule_id+"_"+index;
//               if(value2.risk_details&&value2.risk_details.length>0){
//                   value2.risk_details.map((value3)=>{
//                       value3["rule_id"]=value.rule_id;
//                       value3["rule_detail_id"]=value2["rule_detail_id"];
//                       map.list3.push(value3);  
//                   })
//               }
//               delete value2.risk_details;
//               map.list2.push(value2);
//           })
//       }
//       delete value.risk_detail
//       return value;
// })
// console.log(map);
// var item="a";
// try{
//     var b= JSON.parse(item);
//     console.log(b)
// }catch(e){
   
// }
// var a1={
//   "1":"2"
// }
// var b1={
//     "2":"3",
//     "a":[1,234,4]
// }

// var msg={
//     "07d":"033",
//     "msg1":{
//         "073":"abc",
//         "082":"abcd"
//     }
// }
// var a={};
// a.item={};
// for(var key in msg.msg1){
//     a.item["msg"+key]=msg.msg1[key]
// }
// var msg2={
//     ...msg,
//     ...msg.msg1?msg.msg1:null
// }
// var map={id:"100","response":{"status":"OK","message":{"07d":1,"14d":3,"21d":4,"30d":5,"60d":19,"90d":41,"total":57}}};
// function json2firehose210(item){
//     var returnmap={};
//     returnmap['item']={};
//     if(item.response&&item.response!="{}"){
//         returnmap['item']["res_status"]=item.response.status;
//         returnmap['item']["message"]="";
//         if(item.response.message){
//             if(typeof(item.response.message)=='object'){
//                 for(var key in item.response.message){
//                   returnmap['item']["msg"+key]= item.response.message[key]
//                 }
//                 //   returnmap['item']={
//                 //       ...returnmap['item'],
//                 //       ...item.response.message
//                 //   }
//             }else{
//                 returnmap['item']["message"]=item.response.message;
//             }
//         }
//     }
//     delete item["response"];
//     returnmap['item'] ={
//             ...returnmap['item'],
//             ...item,
//         }
//     console.log(returnmap);
// }
// json2firehose210(map)


// var responseStr=/response":{/;
// var responseStr1=/response/;
// var a='response":""';
//   if(((responseStr1.test(a)&&responseStr.test(a))||!responseStr1.test(a))){
//       console.log("2222")
      
//   }

// var change=undefined;
// console.log(change.aa)
// var a=[1,2,3,4];
// for(let i=0;i<a.length;i++){
//     switch(a[i]){
//         case 1:
//             console.log(1)
//             break;
//         case 2:
//             console.log(2)
//             break;
//     }
//     console.log(11)
// }
// let b = "qaqqqq";
// an(b)
// function an(aaa){
//     console.log(aaa)
// }
// var a=["","",'{1:2}']
// var b =[]
// a.map(value=>{
//      if (value !== "" && value != undefined) {
//             b.push(value);
//         }
//     return value;
// })
// console.log(b)
// var a=""
// console.log(a.substring(0, 1));
// var map=[{"1":"2"},{"2":"3"}]
// var detail=[]
// map.map((value)=>{
//     detail.push({ Data:Buffer.from(JSON.stringify(value, null, 2))})
//       return "";
//     });

// console.log(detail[1])



// const pg = require('pg');
// const pool = new pg.Pool({
//     host: 'rm-d9jx79xi30ujo27hpoo.pgsql.ap-southeast-5.rds.aliyuncs.com',
//     port: 3432,
//     user: 'rpreadonly',
//     password: '9Vt6K4CYGrDcfaGyfu92',
//     database: 'postgres',
//     max: 20,
//     idleTimeoutMillis: 30000,
//     connectionTimeoutMillis: 2000
// });

// async function query (q, parameters) {
//   const client = await pool.connect();
//   let res;
//   try {
//     await client.query('BEGIN')
//     try {
//       res = await client.query(q, parameters)
//       await client.query('COMMIT')
//     } catch (err) {
//       await client.query('ROLLBACK')
//       throw err
//     }
//   } finally {
//     client.release()
//   }
//   return res
// }


// exports.handler = async (event) => {
//     try {
//         console.log(event)
//         var sql = `
//             select
//             tmp.id,
//             tmp.customer_id,
//             tmp.status status,
//             tmp.sub_status sub_status,
//             tmp.loan_type loan_type,
//             to_char(tmp.create_time :: timestamp, 'YYYY-MM-DD HH24:MI:SS.MS') create_time,
//             case 
//             when lp.last_punishment_time is null then 0
//             else DATE_PART('day', lp.last_punishment_time - lp.due_date) end overdue_days
//             from (
//               select c.mobile, l.id, l.customer_id, l.create_time, l.status, l.sub_status,
//               case when l.paid_off_mode = 'ROLLOVER' then 'ROLLOVER' else l.loan_type end loan_type
//               from t_customer c
//               left join t_loan_app l
//               on c.id = l.customer_id
//               where c.mobile = ANY($1::text[])
//               ) tmp
//             left join t_lpay lp
//             on (tmp.id = lp.loan_app_id)
//         `;
//         const { rows } = await query(sql, [event]);
//         const results = []
//         for (const row of rows) {
//           const result = {
//             id: row.id,
//             customerId: row.customer_id,
//             loanAppStatus: row.status,
//             loanAppSubStatus: row.sub_status,
//             loanType: row.loan_type,
//             createTime: row.create_time,
//             overdueDay: row.overdue_days
//           }
//           results.push(result)
//         }
//         console.log(JSON.stringify(results));
//         return results
//     } catch (err) {
//       console.log(err)
//     }
// };
//   const tmp = '{"id":"11506494","customer_id":"1","loan_id":"1","channel":"10003","channel_id":"0-39520838","thirdparty_id":"39520838","status":"40","retry_times":null,"response":"SendSmsResponse.Message(to=006281219706884, status=Accepted, reference=39520838, parts=1, details=null, code=0)","create_time":"2020-01-06 07:09:48.197597+00","update_time":"2020-01-06 07:09:48.36846+00","client_id":"0","query_key":null}'
//   console.log(JSON.stringify( JSON.parse(tmp), null, 2))
//                 // return {Data:Buffer.from(JSON.stringify(tmp, null, 2))}

// try {
//       const response = await rekognition.indexFaces(params).promise();
//       const reqs = [];
//       for (const record of response.FaceRecords) {
//           reqs.push(saveFaceIndex(json.tableName, json.customerId, json.bucket, json.path, record));
//       }
//       await Promise.all(reqs);
//       console.log(`Save ${reqs.length} records successfully.`);
//     } catch (err) {
//       console.error('error', JSON.stringify(err, null, 2));
//     }
//     var tmp='{"change":[{"kind":"update","schema":"public","table":"t_task","columnnames":["id","customer_id","loan_id","channel","channel_id","thirdparty_id","status","retry_times","response","create_time","update_time","client_id","query_key"],"columntypes":["bigint","bigint","bigint","integer","character varying(128)","character varying(128)","integer","integer","text","timestamp with time zone","timestamp with time zone","integer","character varying(40)"],"columnvalues":[11509278,3552186,null,30,"3552186","TASKPR105002202001061436270900201982",40,null,"{\\"code\\":0,\\"data\\":{\\"identity_code\\":\\"3175100307880006\\",\\"created_time\\":\\"2020-01-06 14:36:28\\",\\"channel_src\\":null,\\"user_mobile\\":\\"85886194269\\",\\"task_data\\":{\\"bpjs_digital_card\\":[],\\"profile\\":{\\"birthday\\":\\"07/03/1988\\",\\"address\\":\\"JL SPG VII\\",\\"kpj\\":\\"18006321212\\",\\"phone\\":\\"085770079314\\",\\"real_name\\":\\"DEDE SANJAYA\\",\\"identity_number\\":\\"3175100307880006\\",\\"email\\":\\"dedesanjaya114@gmail.com\\"},\\"claim_detail\\":[],\\"bpjs_balance\\":[]},\\"user_name\\":null,\\"real_name\\":null,\\"channel_code\\":\\"105002\\",\\"channel_type\\":\\"PR\\",\\"channel_attr\\":null,\\"lost_data\\":null},\\"message\\":\\"success\\",\\"task_id\\":\\"TASKPR105002202001061436270900201982\\"}","2020-01-06 07:36:31.869222+00","2020-01-06 07:36:31.89417+00",1,"b28085b8-1a3a-4a23-b3ff-fb11e5b7300f"]}]}'
//     function truncate(map){ 
//         var change=map;
//         change= JSON.parse(change).change[0];
//         if(change){
//             var kind=change.kind;
//             var tableNm=change.table;
//             var schema=change.schema;
//             if ("t_task"==tableNm && "public"==schema && "update"==kind) {
//                 var issuccess=true;
//                 var json="{";
//                 var columnvalues= change.columnvalues;
//                 var columnnames=change.columnnames;
//                 for(var i=0;i<columnnames.length;i++){
//                     if(columnnames[i]=="status"&&columnvalues[i]!=40){
//                         issuccess=!issuccess;
//                         break;
//                     }
//                     if(i==columnnames.length-1){
//                       json+=('\"'+columnnames[i]+'\"'+":"+(columnvalues[i]!=null?'\"'+ columnvalues[i] + '\"':columnvalues[i]));
//                     }else{
//                          if ("response"==columnnames[i]) {
//                              if(columnvalues[i]&&columnvalues[i].substring(0, 1)=="{"){
//                                   json+='\"'+columnnames[i]+'\"'+":"+columnvalues[i]+",";
//                              }else{
//                                  json+='\"'+columnnames[i]+'\"'+":"+(columnvalues[i]!=null?'\"'+columnvalues[i]+'\"':columnvalues[i])+",";
//                              }
//                          }else{
//                              json+='\"'+columnnames[i]+'\"'+":"+(columnvalues[i]!=null?'\"'+columnvalues[i]+'\"':columnvalues[i])+",";
//                          }
                    
//                   }
//                 }
//                 if (issuccess) {
//                     json+="}";
//                     console.log(json)
//                     return json;
//                     }
//             }; 
//         }
//         return null
// }
// truncate(tmp)

// var recordlist_all=[1,23,3,5,6,78,6,3,5,3,4,6,4,3,45,6,3,2,3];
// var recordlist=[];
// for(var a=0;a<recordlist_all.length;a++){
//     if(a==0){
//         var list_child=[];
//         var recordlist=[];
//         list_child.push(recordlist_all[0])
//     }else{
//         if(a%5==0){
//             list_child.push(recordlist_all[a])
//             recordlist.push(list_child);
//             list_child=[]
//         }else{
//             list_child.push(recordlist_all[a])
//         }
//     }
//     if(a==recordlist_all.length-1&&list_child.length>0){
//         recordlist.push(list_child);
//     }
// }
// console.log(recordlist)



// try {
//       const response = await rekognition.indexFaces(params).promise();
//       const reqs = [];
//       for (const record of response.FaceRecords) {
//           reqs.push(saveFaceIndex(json.tableName, json.customerId, json.bucket, json.path, record));
//       }
//       await Promise.all(reqs);
//       console.log(`Save ${reqs.length} records successfully.`);
//     } catch (err) {
//       console.error('error', JSON.stringify(err, null, 2));
//     }
// var  map={"10":[{"item":{"id":"22"},"item1":[{"id":"22","id1":"2222"},{"id":"22","id1":"2222"}]}],"20":[],"40":{"0":[],"2":[]},"50":[],"60":[],"70":[],"80":[],"90":[],"200":[],"210":[],"220":[],"240":[],"250":[],"290":[]};
// async  function send2filehose(channelmap){
//     for(var key in channelmap){
//         console.log(channelmap[key])
//     }
// }
// send2filehose(map)
// try {
//       const response = await rekognition.indexFaces(params).promise();
//       const reqs = [];
//       for (const record of response.FaceRecords) {
//           reqs.push(saveFaceIndex(json.tableName, json.customerId, json.bucket, json.path, record));
//       }
//       await Promise.all(reqs);
//       console.log(`Save ${reqs.length} records successfully.`);
//     } catch (err) {
//       console.error('error', JSON.stringify(err, null, 2));
//     }
// function b(value){
//     console.log(value)
// }
// function aaaa(){
//     return [b(1),b(45),b(66),b(7),b(8),b(9)]
// }
// var abv=aaaa();
// // Promise.all(abv);
