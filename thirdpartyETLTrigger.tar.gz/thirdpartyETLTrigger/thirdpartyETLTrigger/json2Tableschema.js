// var firehose=require("./send2Firehose");
// var responseStr=/response":{/;
// var responseStr1=/response/;
// function json2firehose(jsonlist){
//     if(jsonlist.length>0){
//         jsonlist.forEach(function(item,index){
//         //验证json 
//         try{
//             if(item&&item.length>2&&((responseStr1.test(item)&&responseStr.test(item))||!responseStr1.test(item))){
//                 item=JSON.parse(item);
//                 if(item.customer_id){
//                     if(item.channel=='10'){
//                         json2firehose10(item);
//                     }else if(item.channel=='20'){
//                         json2firehose20(item);
//                     }else if(item.channel=='40'){
//                         if(item.client_id=='0'||!item.client_id){
//                             json2firehose40(item);
//                         }else if(item.client_id=='2'){
//                             json2firehose40_forRepublika(item);
//                         }
//                     }else if(item.channel=='50'){
//                         json2firehose50(item);
//                     }else if(item.channel=='60'){
//                         json2firehose60(item);
//                     }else if(item.channel=='70'){
//                         json2firehose70(item);
//                     }else if(item.channel=='80'){
//                         json2firehose80(item);
//                     }else if(item.channel=='90'){
//                         json2firehose90(item);
//                     }else if(item.channel=='200'){
//                         json2firehose200(item);
//                     }else if(item.channel=='210'){
//                         json2firehose210(item);
//                     }else if(item.channel=='220'){
//                         json2firehose220(item);
//                     }else if(item.channel=='240'){
//                         json2firehose240(item);
//                     }else if(item.channel=='250'){
//                         json2firehose250(item);
//                     }else if(item.channel=='290'){
//                         json2firehose290(item);
//                     }
//                 }
//             }
//         }catch(e){
//           console.log(item);
//           console.log("logeeeeeeeee",e)
//         }   
//       })
//     }
// };
// //TONGDUN_KTP(10)
// function json2firehose10(item){
//     let relItem=JSON.parse(JSON.stringify(item));
//     if(item.response&&item.response.data&&item.response.data!="{}"){
//         item.identity_code=item.response.data.identity_code;
//         item.channel_src=item.response.data.channel_src;
//         item.user_mobile=item.response.data.user_mobile;
//         item.real_name=item.response.data.real_name;
//         item.channel_code=item.response.data.channel_code;
//         item.channel_type=item.response.data.channel_type;
//         item.message=item.response.message;
//         item.task_id=item.response.task_id;
//         item.code=item.response.code;
//         item.task_data_return_info_ktp_result_wrong_type=item.response.data.task_data.return_info.ktp_result.wrong_type;
//         item.task_data_return_info_is_match=item.response.data.task_data.return_info.is_match;
//         item.task_data_return_info_phone_is_match=item.response.data.task_data.return_info.phone_is_match;
//         delete item.response;
//     }
//     firehose.send2filehose(item.channel,item,item.client_id,relItem);
// }
// //    TONGDUN_FACEBOOK(20)
// function json2firehose20(item){
//     let relItem=JSON.parse(JSON.stringify(item));
//     var returnmap={};
//     var thirdparty_id=item.thirdparty_id;
//     if(item.response&&item.response.data&&item.response.data!="{}"){
//         // var friends_info=item.response.data.task_data.friends_info;
//         //friends_info
//         if(item.response.data.task_data.friends_info&&item.response.data.task_data.friends_info.length>0){
//             returnmap["friends_info"] = item.response.data.task_data.friends_info.map((rs,index) =>{
//             rs["customer_id"]=item.customer_id;    
//             rs["loan_id"]=item.loan_id;
//             rs["create_time"]=item.create_time;  
//             rs["query_key"]=item.query_key; 
//             rs["thirdparty_id"]=item.thirdparty_id;
//             return rs;
//             })
//         };
//         delete  item.response.data.task_data.friends_info;
//         //family_info
//         if(item.response.data.task_data.family_info&&item.response.data.task_data.family_info.length>0){
//              returnmap["family_info"] = item.response.data.task_data.family_info.map((rs,index) =>{
//             rs["thirdparty_id"]=item.thirdparty_id;
//             rs["customer_id"]=item.customer_id;    
//             rs["loan_id"]=item.loan_id;
//             rs["create_time"]=item.create_time;  
//             rs["query_key"]=item.query_key; 
//             return rs;
//             })
//         };
//         delete  item.response.data.task_data.family_info;
//         if(item.response.data.task_data.education_info.college_info&&item.response.data.task_data.education_info.college_info.length>0){
//             returnmap["education_info_college_info"] = item.response.data.task_data.education_info.college_info.map((rs,index) =>{
//             rs["thirdparty_id"]=item.thirdparty_id;
//             rs["customer_id"]=item.customer_id;    
//             rs["loan_id"]=item.loan_id;
//             rs["create_time"]=item.create_time;  
//             rs["query_key"]=item.query_key; 
//             return rs;
//             })
//         };
//         delete  item.response.data.task_data.education_info.college_info;
//         if(item.response.data.task_data.education_info.highschool_info&&item.response.data.task_data.education_info.highschool_info.length>0){
//             returnmap["education_info_highschool_info"]= item.response.data.task_data.education_info.highschool_info.map((rs) =>{
//             rs["thirdparty_id"]=item.thirdparty_id;
//             rs["customer_id"]=item.customer_id;    
//             rs["loan_id"]=item.loan_id;
//             rs["create_time"]=item.create_time;  
//             rs["query_key"]=item.query_key; 
//             return rs;
//             })
//         };
//         delete  item.response.data.task_data.education_info.highschool_info;
//         if(item.response.data.task_data.messenger_info&&item.response.data.task_data.messenger_info.length>0){
//             returnmap["messenger_info"] = item.response.data.task_data.messenger_info.map((rs,index) =>{
//             rs["thirdparty_id"]=item.thirdparty_id;
//             rs["customer_id"]=item.customer_id;    
//             rs["loan_id"]=item.loan_id;
//             rs["create_time"]=item.create_time;  
//             rs["query_key"]=item.query_key; 
//             return rs;
//             })
//         };
//         delete  item.response.data.task_data.messenger_info;
//         if(item.response.data.task_data.work_info&&item.response.data.task_data.work_info.length>0){
//             returnmap["work_info"]= item.response.data.task_data.work_info.map((rs,index) =>{
//             rs["thirdparty_id"]=item.thirdparty_id;
//             rs["customer_id"]=item.customer_id;    
//             rs["loan_id"]=item.loan_id;
//             rs["create_time"]=item.create_time;  
//             rs["query_key"]=item.query_key; 
//             return rs;
//             })
//         };
//         delete  item.response.data.task_data.work_info;
//         if(item.response.data.task_data.historical_login_info&&item.response.data.task_data.historical_login_info.length>0){
//             returnmap["historical_login_info"]= item.response.data.task_data.historical_login_info.map((rs,index) =>{
//             rs["thirdparty_id"]=item.thirdparty_id;
//             rs["customer_id"]=item.customer_id;    
//             rs["loan_id"]=item.loan_id;
//             rs["create_time"]=item.create_time;  
//             rs["query_key"]=item.query_key; 
//             return rs;
//             })
//         };
//         delete  item.response.data.task_data.historical_login_info;
//         if(item.response.data.task_data.friends_publish_info&&item.response.data.task_data.friends_publish_info.length>0){
//             returnmap["friends_publish_info"]= item.response.data.task_data.friends_publish_info.map((rs,index) =>{
//             rs["thirdparty_id"]=item.thirdparty_id;
//             rs["customer_id"]=item.customer_id;    
//             rs["loan_id"]=item.loan_id;
//             rs["create_time"]=item.create_time;  
//             rs["query_key"]=item.query_key; 
//             return rs;
//             })
//         };
//         delete  item.response.data.task_data.friends_publish_info;
//         if(item.response.data.task_data.publish_info&&item.response.data.task_data.publish_info.length>0){
//             returnmap["publish_info"]= item.response.data.task_data.publish_info.map((rs,index) =>{
//             rs["thirdparty_id"]=item.thirdparty_id;
//             rs["customer_id"]=item.customer_id;    
//             rs["loan_id"]=item.loan_id;
//             rs["create_time"]=item.create_time;  
//             rs["query_key"]=item.query_key; 
//             rs["likenames"]=rs.likenames.toString();
//             return rs;
//             })
//         };
//         delete  item.response.data.task_data.publish_info;
//         if(item.response.data.task_data.base_info){
//           Object.keys(item.response.data.task_data.base_info).forEach(function(key){
//               if(key=='mobilephones'||key=='emails'){
//                     item.response.data.task_data.base_info[key]=item.response.data.task_data.base_info[key].toString();
//                 }
//           item[key]=item.response.data.task_data.base_info[key];
//           });
//         };
//         if(item.response.data.task_data.payments_info){
//             item["payments_info"]=item.response.data.task_data.payments_info+"";
//         };
//         delete  item.response.data.task_data;
//     }
//     item={
//             ...item,
//             ...item.response?item.response={
//                 ...item.response,
//                 ...item.response.data?item.response.data:null
//             }:null
//         }
//     delete item.response;
//     delete item.data;
//     returnmap["item"]=item;
//     // console.log("returnmap-------------",returnmap)
//     firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
    
// }
// //    TONGDUN_GUARD(40), client_id is null or client_id='0'
// function json2firehose40(item){
//     let relItem=JSON.parse(JSON.stringify(item));
//     var returnmap={};
//     var thirdparty_id=item.thirdparty_id;
//     if(item.response&&item.response!="{}"){
//         item["success"]=item.response.success;
//         // item["id"]=item.response.id;
//         //INFOANALYSIS
//       if(item.response.result_desc.INFOANALYSIS){
//           item["address_detect_true_ip_address"]=item.response.result_desc.INFOANALYSIS.address_detect.true_ip_address;
//           item["device_info_error"]=item.response.result_desc.INFOANALYSIS.device_info.error;
//           delete item["INFOANALYSIS"];
//       } 
//       //ANTIFRAUD
//       if(item.response.result_desc.ANTIFRAUD){
//             item["final_score"]=item.response.result_desc.ANTIFRAUD.final_score;
//             item["final_decision"]=item.response.result_desc.ANTIFRAUD.final_decision;
//             returnmap["risk_details"]=[];
//             returnmap["risk_detail"]=[];
//             if(item.response.result_desc.ANTIFRAUD.risk_items&&item.response.result_desc.ANTIFRAUD.risk_items.length>0){
//                 //risk_items
//                  returnmap["risk_items"]=item.response.result_desc.ANTIFRAUD.risk_items.map((value,index)=>{
//                       value["customer_id"]=item.customer_id;
//                       value["loan_id"]=item.loan_id;
//                       value["create_time"]=item.create_time;
//                       value["query_key"]=item.query_key;
//                       value["thirdparty_id"]=item.thirdparty_id;
//                       if(value.risk_detail&&value.risk_detail.length>0){
//                           //risk_detail
//                           value.risk_detail.map((value2)=>{
//                               value2["rule_id"]=value.rule_id;
//                               value2["rule_detail_id"]=value.rule_id+"_"+index;
//                               value2["customer_id"]=item.customer_id;
//                               value2["loan_id"]=item.loan_id;
//                               value2["create_time"]=item.create_time;
//                               value2["query_key"]=item.query_key;
//                               value2["thirdparty_id"]=item.thirdparty_id;
//                               if(value2.risk_details&&value2.risk_details.length>0){
//                                   //risk_details
//                                   value2.risk_details.map((value3)=>{
//                                       value3["rule_id"]=value.rule_id;
//                                       value3["rule_detail_id"]=value2["rule_detail_id"];
//                                       value3["customer_id"]=item.customer_id;
//                                       value3["loan_id"]=item.loan_id;
//                                       value3["create_time"]=item.create_time;
//                                       value3["query_key"]=item.query_key;
//                                       value3["thirdparty_id"]=item.thirdparty_id;
//                                       if(value3.mh_value&&typeof(value3.mh_value)=='object'){
//                                           value3["mh_value"]=value3["mh_value"].toString();
//                                         }
//                                       returnmap["risk_details"].push(value3);  
//                                   })
//                               }
//                               delete value2.risk_details;
//                               returnmap["risk_detail"].push(value2);
//                           })
//                       }
//                       delete value.risk_detail
//                       return value;
//                 })
//             }
//       }
//     }
//     delete  item["response"];
//     returnmap["item"]=item;
//     firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
    
// }
// //    TONGDUN_KTP_OCR(40) client_id=2
// function json2firehose40_forRepublika(item){
//     let relItem=JSON.parse(JSON.stringify(item));
//     var returnmap={};
//     var thirdparty_id=item.thirdparty_id;
//     if(item.response&&item.response!="{}"){
//         item["success"]=item.response.success;
//         // item["id"]=item.response.id;
//         //INFOANALYSIS
//       if(item.response.result_desc&&item.response.result_desc.INFOANALYSIS){
//           item["address_detect_true_ip_address"]=item.response.result_desc.INFOANALYSIS.address_detect.true_ip_address;
//           item["device_info_error"]=item.response.result_desc.INFOANALYSIS.device_info.error;
//           delete item["INFOANALYSIS"];
//       } 
//       //ANTIFRAUD
//       if(item.response.result_desc&&item.response.result_desc.ANTIFRAUD){
//             item["final_score"]=item.response.result_desc.ANTIFRAUD.final_score;
//             item["final_decision"]=item.response.result_desc.ANTIFRAUD.final_decision;
//             if(item.response.result_desc.ANTIFRAUD.risk_items&&item.response.result_desc.ANTIFRAUD.risk_items.length>0){
//                 //risk_items
//                 returnmap["risk_detail"]=[];
//                 returnmap["frequency_detail_list"]=[];
//                 returnmap["platform_detail_dimension"]=[];
//                 returnmap["platform_detail"]=[];
//                 returnmap["platform_detail_dimension_detail"]=[];
//                  returnmap["risk_items"]=item.response.result_desc.ANTIFRAUD.risk_items.map((value,index)=>{
//                       value["customer_id"]=item.customer_id;
//                       value["loan_id"]=item.loan_id;
//                       value["create_time"]=item.create_time;
//                       value["query_key"]=item.query_key;
//                       value["thirdparty_id"]=item.thirdparty_id;
//                       if(value.risk_detail&&value.risk_detail.length>0){
//                           //risk_detail
//                           value.risk_detail.map((value2)=>{
//                               value2["rule_id"]=value.rule_id;
//                               value2["rule_detail_id"]=value.rule_id+"_"+index;
//                               value2["type"]=value2.type
//                               value2["customer_id"]=item.customer_id;
//                               value2["loan_id"]=item.loan_id;
//                               value2["create_time"]=item.create_time;
//                               value2["query_key"]=item.query_key;
//                               value2["thirdparty_id"]=item.thirdparty_id;
//                               if(value2.frequency_detail_list&&value2.frequency_detail_list.length>0){
//                                   //risk_details
//                                   value2.frequency_detail_list.map((value3)=>{
//                                       value3["rule_id"]=value.rule_id;
//                                       value3["rule_detail_id"]=value2["rule_detail_id"];
//                                       value3["customer_id"]=item.customer_id;
//                                       value3["loan_id"]=item.loan_id;
//                                       value3["create_time"]=item.create_time;
//                                       value3["query_key"]=item.query_key;
//                                       value3["thirdparty_id"]=item.thirdparty_id;
//                                       value3["data"]=value3.data?"":value3.data;  
//                                       value3["detail"]=value3.detail
//                                       returnmap["frequency_detail_list"].push(value3);  
//                                   })
//                               }
//                                 if(value2.platform_detail_dimension&&value2.platform_detail_dimension.length>0){
//                                   //risk_details
//                                   value2.platform_detail_dimension.map((value3,index2)=>{
//                                       value3["rule_id"]=value.rule_id;
//                                       value3["rule_detail_id"]=value2["rule_detail_id"];
//                                       value3["rule_detail_id2"]=value2["rule_detail_id"]+"_"+index2;
//                                       value3["customer_id"]=item.customer_id;
//                                       value3["loan_id"]=item.loan_id;
//                                       value3["create_time"]=item.create_time;
//                                       value3["query_key"]=item.query_key;
//                                       value3["thirdparty_id"]=item.thirdparty_id;
//                                       if(value3.detail&&value3.detail.length>0){
//                                           //risk_details
//                                           value3.detail.map((value4)=>{
//                                               value4["rule_id"]=value.rule_id;
//                                               value4["rule_detail_id"]=value2["rule_detail_id"];
//                                               value4["rule_detail_id2"]=value3["rule_detail_id2"];
//                                               value4["customer_id"]=item.customer_id;
//                                               value4["loan_id"]=item.loan_id;
//                                               value4["create_time"]=item.create_time;
//                                               value4["query_key"]=item.query_key;
//                                               value4["thirdparty_id"]=item.thirdparty_id;
//                                               returnmap["platform_detail_dimension_detail"].push(value4);
                                               
//                                           })
//                                       }
//                                       delete value3.detail;
//                                       returnmap["platform_detail_dimension"].push(value3);
//                                   })
//                               }
//                                 if(value2.platform_detail&&value2.platform_detail.length>0){
//                                   //platform_detail
//                                   value2.platform_detail.map((value3)=>{
//                                       value3["rule_id"]=value.rule_id;
//                                       value3["rule_detail_id"]=value2["rule_detail_id"];
//                                       value3["customer_id"]=item.customer_id;
//                                       value3["loan_id"]=item.loan_id;
//                                       value3["create_time"]=item.create_time;
//                                       value3["query_key"]=item.query_key;
//                                       value3["thirdparty_id"]=item.thirdparty_id;
//                                       returnmap["platform_detail"].push(value3);
//                                   })
//                               }
//                               delete value2.risk_details;
//                               delete value2.platform_detail_dimension;
//                               delete value2.platform_detail;
//                               delete value2.frequency_detail_list;
//                               returnmap["risk_detail"].push(value2);
//                           })
//                       }
//                       delete value.risk_detail
//                       return value;
//                 })
//             }
//       }
//     }
//     delete  item["response"];
//     returnmap["item"]=item;
//     firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
// }
// //    TONGDUN_KTP_OCR(50)
// function json2firehose50(item){
//      let relItem=JSON.parse(JSON.stringify(item));
//      var returnmap={};
//      if(item.response&&item.response.data&&item.response.data!="{}"){
//          returnmap["item"] ={
//                 ...item.response?item.response:null,
//                 ...item.response.data?item.response.data:null,
//                 ...item.response.data.task_data?item.response.data.task_data={
//                     ...item.response.data.task_data.other?item.response.data.task_data.other:null,
//                     ...item.response.data.task_data.profile?item.response.data.task_data.profile:null,
//                     ...item.response.data.task_data.return_info?item.response.data.task_data.return_info={
//                         ...item.response.data.task_data.return_info,
//                         ...item.response.data.task_data.return_info.ktp_result?item.response.data.task_data.return_info.ktp_result:null
//                     }:null,
//                 }:null,
//             }
//         delete item["response"];
//         delete item["data"];
//         delete item["task_data"];
//         delete item["other"];
//         delete item["profile"];
//         delete item["return_info"];
//         delete item["ktp_result"];
//     }
//     returnmap['item']={
//       ...item,
//       ...returnmap['item']
//     }
//     firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
// }
// //    ADVANCE_AI_MULTI_PLATFORM(60),
// function json2firehose60(item){
//      let relItem=JSON.parse(JSON.stringify(item));
//     var returnmap={};
//     if(item.response&&item.response.data&&item.response.data!="{}"){
//         if(item.response.data&&item.response.data.statistics){
//             if(item.response.data.statistics.statisticCustomerInfo&&item.response.data.statistics.statisticCustomerInfo.length>0){
//                 returnmap["statisticCustomerInfolist"]=item.response.data.statistics.statisticCustomerInfo.map((value)=>{
//                     value["customer_id"]=item.customer_id;
//                     value["loan_id"]=item.loan_id;
//                     value["create_time"]=item.create_time;
//                     value["query_key"]=item.query_key;
//                     value["thirdparty_id"]=item.thirdparty_id;
//                     return  value;
//                 })
//             }
//             if(item.response.data.statistics.lastTwoWeeksQueryInfo&&item.response.data.statistics.lastTwoWeeksQueryInfo.length>0){
//                 returnmap["lastTwoWeeksQueryInfo"]=item.response.data.statistics.lastTwoWeeksQueryInfo.map((value)=>{
//                     value["customer_id"]=item.customer_id;
//                     value["loan_id"]=item.loan_id;
//                     value["create_time"]=item.create_time;
//                     value["query_key"]=item.query_key;
//                     value["thirdparty_id"]=item.thirdparty_id;
//                     return  value;
//                 })
//             }
//             if(item.response.data.records&&item.response.data.records.length>0){
//                 returnmap["records"]=item.response.data.records.map((value)=>{
//                     value["customer_id"]=item.customer_id;
//                     value["loan_id"]=item.loan_id;
//                     value["create_time"]=item.create_time;
//                     value["query_key"]=item.query_key;
//                     value["thirdparty_id"]=item.thirdparty_id;
//                     value["queryDates"]=value.queryDates.toString();
//                     return  value;
//                 })
//             }
//         }  
//     }
//     delete item["response"]["data"];
//     item ={
//             ...item,
//             ...item.response?item.response:null,
//         }
//     delete item["response"];
//     delete item["data"];
//     returnmap['item']=item;
//     // console.log("channel60",returnmap);
//   firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
// }
// //    IZI_PHONE_VERIFY(70)
// function json2firehose70(item){
//      let relItem=JSON.parse(JSON.stringify(item));
//     var returnmap={};
//     returnmap['item']={};
//     if(item.response&&item.response!="{}"){
//         returnmap['item']["res_status"]=item.response.status;
//         returnmap['item']["message"]=item.response.message;
//     }
//     delete item["response"];
//     returnmap['item'] ={
//             ...returnmap['item'],
//             ...item,
//         }
//     // console.log("channel70",returnmap);
//   firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
// }
// //    IZI_PHONE_AGE(80)
// function json2firehose80(item){
//      let relItem=JSON.parse(JSON.stringify(item));
//     var returnmap={};
//     returnmap['item']={};
//     if(item.response&&item.response!="{}"){
//         returnmap['item']["res_status"]=item.response.status;
//         returnmap['item']["message"]="";
//         if(item.response.message){
//             if(typeof(item.response.message)=='object'){
//               returnmap['item']={
//                   ...returnmap['item'],
//                   ...item.response.message
//               }
//             }else{
//                 returnmap['item']["message"]=item.response.message;
//             }
//         }
//     }
//     delete item["response"];
//     returnmap['item'] ={
//             ...returnmap['item'],
//             ...item,
//         }
//     console.log("channel80",returnmap);
//   firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
// }
// //    IZI_PHONE_WHATSAPP(90)
// function json2firehose90(item){
//      let relItem=JSON.parse(JSON.stringify(item));
//     var returnmap={};
//     returnmap['item']={};
//     if(item.response&&item.response!="{}"){
//         returnmap['item']["res_status"]=item.response.status;
//       if(item.response.message){
//             if(typeof(item.response.message)=='object'){
//               returnmap['item']={
//                   ...returnmap['item'],
//                   ...item.response.message
//               }
//             }else{
//                 returnmap['item']["message"]=item.response.message;
//             }
//         }
//     }
//     delete item["response"];
//     returnmap['item'] ={
//             ...returnmap['item'],
//             ...item,
//         }
//     firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
// }
// //   KTP_MULTI_PLATFORM_DETECTION(200),
// function json2firehose200(item){
//      let relItem=JSON.parse(JSON.stringify(item));
//     var returnmap={};
//     returnmap['item']=item;
//     if(item.response&&item.response!="{}"){
//         returnmap['item']["res_status"]=item.response.status;
//         if(item.response.message){
//             if(typeof(item.response.message)=='object'){
//               returnmap['item']={
//                   ...returnmap['item'],
//                   ...item.response.message
//               }
//             }else{
//                 returnmap['item']["message"]=item.response.message;
//             }
//         }
//     }
//     delete  returnmap['item'].response;
//     firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
// }
// //    KTP_MULTI_PLATFORM_DETECTION_BRIEF_CHECK(210),
// function json2firehose210(item){
//      let relItem=JSON.parse(JSON.stringify(item));
//     var returnmap={};
//     returnmap['item']={};
//     if(item.response&&item.response!="{}"){
//         returnmap['item']["res_status"]=item.response.status;
//         returnmap['item']["message"]="";
//         if(item.response.message){
//             if(typeof(item.response.message)=='object'){
//               returnmap['item']={
//                   ...returnmap['item'],
//                   ...item.response.message
//               }
//             }else{
//                 returnmap['item']["message"]=item.response.message;
//             }
//         }
//     }
//     delete item["response"];
//     returnmap['item'] ={
//             ...returnmap['item'],
//             ...item,
//         }
//     // console.log(returnmap)    
//     firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
// }
// //    IZI_BLACK_CHECK(220),
// function json2firehose220(item){
//      let relItem=JSON.parse(JSON.stringify(item));
//     var returnmap={};
//     returnmap['item']=item;
//     if(item.response&&item.response!="{}"){
//         returnmap['item']["res_status"]=item.response.status;
//         returnmap['item']['message']=item.response.message;
//     }
//     delete returnmap['item'].response
//     firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
// }
// //    IDENTITY_CHECK(230),
// function json2firehose230(item){
//     let relItem=JSON.parse(JSON.stringify(item));
//     var returnmap={};
//     returnmap['item']=item;
//     if(item.response&&item.response!="{}"){
//         returnmap['item']["res_status"]=item.response.status;
//         if(item.response.message){
//              delete item.response.message.id;
//              returnmap['item']={
//                 ...returnmap['item'],
//                 ...item.response.message
//              }
//         }
//     }
//     delete  returnmap['item'].response;
//     // console.log(returnmap)    
//     firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
// }
// //    YITU_FACE_VERIFY(240),
// function json2firehose240(item){
//     let relItem=JSON.parse(JSON.stringify(item));
//     var returnmap={};
//     returnmap['item']=item;
//     if(item.response&&item.response!="{}"){
//         returnmap['item']={
//             ...returnmap['item'],
//             ...item.response,
//             ...item.response.query_image_package_result?item.response.query_image_package_result:null,
//         }
//     }
//     delete  returnmap['item'].response;
//     delete  returnmap['item'].query_image_package_result;
//     returnmap['item'].query_image_contents=returnmap['item'].query_image_contents?returnmap['item'].query_image_contents.toString():null;
//     // console.log(returnmap)    
//     firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
// }
// //    STI_MOBILE_CHECK(250),
// function json2firehose250(item){
//     let relItem=JSON.parse(JSON.stringify(item));
//     var returnmap={};
//     returnmap['item']=item;
//     if(item.response&&item.response!="{}"){
//         returnmap['detail']=returnmap['item'].response.list;
//         returnmap['item']={
//             ...returnmap['item'],
//             ...item.response.data?item.response.data:null,
//             ...item.response.result?item.response.result:null,
//         }
//          returnmap['detail']=returnmap['detail'].map((value)=>{
//             value["customer_id"]=item.customer_id;
//             value["loan_id"]=item.loan_id;
//             value["create_time"]=item.create_time;
//             value["query_key"]=item.query_key;
//             value["thirdparty_id"]=item.thirdparty_id;
//             return value;
//         })
//     }
//     delete  returnmap['item'].response;
//     // console.log(returnmap)    
//     firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
// }
// function json2firehose290(item){
//      let relItem=JSON.parse(JSON.stringify(item));
//     var returnmap={};
//     returnmap['item']=item;
//     if(item.response&&item.response!="{}"){
//         returnmap['detail']=returnmap['item'].response.reportDetailList;
//         returnmap['item']['res_id']=returnmap['item'].response.id;
//         returnmap['item']={
//             ...returnmap['item'],
//             ...item.response
//         }
//         returnmap['detail']=returnmap['detail'].map((value)=>{
//             value["customer_id"]=item.customer_id;
//             value["loan_id"]=item.loan_id;
//             value["create_time"]=item.create_time;
//             value["query_key"]=item.query_key;
//             value["thirdparty_id"]=item.thirdparty_id;
//             return value;
//         })
//     }
//     delete  returnmap['item'].response;
//     delete  returnmap['item'].reportDetailList;
//     // console.log(returnmap)    
//     firehose.send2filehose(item.channel,returnmap,item.client_id,relItem);
// }
// function verify_json(jsonContent){
//     if(jsonContent.length>1
//         &&(jsonContent[0]=="{"||jsonContent[0]=="[")
//         &&(jsonContent[jsonContent.length-1]=="}"||jsonContent[jsonContent.length-1]=="]")){
//         return true;
//     }
//     return false;
// }
// module.exports = {
//  json2firehose
// }